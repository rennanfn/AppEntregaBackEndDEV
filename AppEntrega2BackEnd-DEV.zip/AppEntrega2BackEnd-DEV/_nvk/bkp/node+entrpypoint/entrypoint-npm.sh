#!/bin/bash
# start apache
echo "Iniciando aplicação node"
exec npm start