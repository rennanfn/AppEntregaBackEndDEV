/* eslint-disable no-cond-assign */
/* eslint-disable no-constant-condition */
/* eslint-disable @typescript-eslint/no-non-null-assertion */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
import * as cron from 'node-cron';
import ColaboradorController from './controller/Cad_Colaborador_Controller';
import CadTokenDB from './modelDB/Cad_Token_DB';
import { pVerbose } from './utils/consoleLog';
import { convertDateTime2String} from './utils/dateNow';

export function configureCronJobs() {
  // Agenda a tarefa todos os dias às 23h, irá gerar token aos novos funcionários caso existir.
  cron.schedule('15 10 * * *', verificaColaborador);
  cron.schedule('20 10 * * *', geraToken);
  cron.schedule('25 10 * * *', verificaDemitidos);
}

async function geraToken() {
  const cadToken = new CadTokenDB({});
  const dataAtual = new Date();
  const dataFormatada = convertDateTime2String(dataAtual);
  console.log('Cron geraToken inicializada em: ', dataFormatada.toString(), pVerbose.aviso);
  cadToken
    .generatorTokensNewFunc()
    .then(result => console.log(result))
    .catch(erro => console.log(erro));
}

async function verificaColaborador() {
  const dataAtual = new Date();
  const dataFormatada = convertDateTime2String(dataAtual);
  try {
    const responseMock: any = {
      status: () => responseMock,
      json: (data: any) => {
        if (data.length > 0) {
          console.log(data)
          console.log(`Encontramos ${data.length} novos cadastros`, pVerbose.aviso);
        } else {
          console.log(`Nenhum registro cadastrado!`, pVerbose.aviso);
        }
        return responseMock
      },
    }
    // Simulando uma requisição POST para atualizar a data
    console.log('Cron verificaColaborador inicializada em: ', dataFormatada.toString(), pVerbose.aviso);
    await ColaboradorController.showColaborador(undefined!, responseMock)

  } catch (error) {
    console.error('Erro ao solicitar dados:', error)
  }
}

async function verificaDemitidos() {
  const dataAtual = new Date();
  const dataFormatada = convertDateTime2String(dataAtual);
  try {
    const responseMock: any = {
      status: () => responseMock,
      json: (data: any) => {
        if (data.length > 0) {
          console.log(data)
          console.log(`Encontramos ${data.length} demitidos`, pVerbose.aviso);
        } else {
          console.log(`Nenhum colaborador demitido!`, pVerbose.aviso);
        }
        return responseMock
      },
    }
    // Simulando uma requisição POST para atualizar a data
    console.log('Cron verificaDemitido inicializada em: ', dataFormatada.toString(), pVerbose.aviso);
    await ColaboradorController.showColaboradorDemitido(undefined!, responseMock)

  } catch (error) {
    console.error('Erro ao solicitar dados:', error)
  }
}

