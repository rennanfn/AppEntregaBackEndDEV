# AppEntrega2BackEnd

<<<<<<< HEAD
Projeto desenvolvido em Node.js Express versão 18.14.2

DEV:

- Adicionado certificados SSL para poder usar HTTPS em PROD e HTTP em DEV;
- Adicionado a biblioteca "dotenv" para criar as variáveis de ambiente somente no projeto dem DEV e assim não precisamos ficar criando as mesmas em nossa maquina, por isso foi necessário alterar o comando "start" no arquivo package.json e lembrar de sempre colocar o arquivo .env no .gitignore para que ele não suba para o GITHUB nem vá para produção, em PROD as variáveis de ambiente são criadas dentro do PM2;
- Sempre configure as URLS permitidas no CORS, por segurança nunca deixe vazio ou com \*.
  -Ao ler o QRCode do colaborador já tem que retornar quais produtos ele pode retirar, então devemos verificar o seguinte:
  [X] Pode retirar esse produto (não consta na tabela restrição);
  [X] O colaborador entrou a menos de 30 dias alguns produtos ele não pode retirar;
  [X] Verificar se o produto tem restrição de comodato;
  [X] Verificar a periodicidade;
  [X] Entrega produto somente no mês do aniversário;

- Pontos que precisam ser revistos:
  [ ] Antes de gravar na tabela de movimentação confirma novamente a quantidade máxima, puxa no banco os produtos e quantidade máxima (pode usar a função buscaProdutosColabPodeRetirar que já faz todas as validações). Isso é porque podemos receber um JSON "manipulado" o usuário pode enviar uma request com um token válido, mas no corpo dela ta falando que ele pode retirar 20 refrigerante de uma quantidade máxima de 20, mas se olharmos na tabela a quantide máxima desse produto pode ser menor;
  [ ] O método getErrorGeneral esta sendo utilizado em vários lugares, mas ele não esta implementado, se cair nele vai dar erro e parar a aplicação (e vai ser necessário acessar o servidor e reiniciar o serviço), precisa implmentar essa função.
  [ ] As validações do ZOD estão fora de um try/catch, se receber algum objeto errado o ZOD vai gerar um erro que chega até escrever no console mas como não tem nenhum "catch" para tratar ele vai parar a aplicação (sendo necessário acessar o servidor e reiniciar o backend), precisa tratar os .parse do ZOD;

Precisa verificar:

- ErroGeneral.getErrorGeneral() parece não funcionar, cuidado com o segundo parâmetro "error: unknown" nas classes que fazem busca no banco esse parâmetro recebe o erro que vem do BD, se jogar esse erro para o frontend pode enviar dados sensíveis fora que para o usuário esse erro é irrelevante pois é técnico.

