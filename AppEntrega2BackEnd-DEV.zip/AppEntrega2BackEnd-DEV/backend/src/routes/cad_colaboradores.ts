/* eslint-disable camelcase */
/* eslint-disable prettier/prettier */
import { Router } from 'express';
import Cad_Colaborador_Controller from '../controller/Cad_Colaborador_Controller';

const cadColaboradoresRoutes = Router();

cadColaboradoresRoutes.get('/', Cad_Colaborador_Controller.show);
cadColaboradoresRoutes.get('/:matricula', Cad_Colaborador_Controller.buscarToken);
cadColaboradoresRoutes.patch('/', Cad_Colaborador_Controller.ativaDesativa);

export default cadColaboradoresRoutes;
