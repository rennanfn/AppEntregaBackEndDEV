/* eslint-disable prettier/prettier */
import { LoginController } from './../controller/Cad_Login_Controller';
import { Router } from 'express';

export const loginRoutes = Router();

loginRoutes.post('/', LoginController.autenticar);
loginRoutes.get('/refreshToken', LoginController.refreshtoken);
