/* eslint-disable camelcase */
/* eslint-disable prettier/prettier */
import { Router } from 'express';
import Cad_Autorizados_Controller from '../controller/Cad_Autorizados_Controller';

const cadAutorizadosRoutes = Router();

cadAutorizadosRoutes.post('/', Cad_Autorizados_Controller.insert);
cadAutorizadosRoutes.put('/', Cad_Autorizados_Controller.update);
cadAutorizadosRoutes.get('/', Cad_Autorizados_Controller.show);
cadAutorizadosRoutes.get('/:matricula', Cad_Autorizados_Controller.find);
cadAutorizadosRoutes.get('/buscarToken/:matricula', Cad_Autorizados_Controller.buscarTokenAut);
cadAutorizadosRoutes.patch('/:matricula', Cad_Autorizados_Controller.ativaDesativa);
cadAutorizadosRoutes.delete('/:matricula', Cad_Autorizados_Controller.delete);

export default cadAutorizadosRoutes;
