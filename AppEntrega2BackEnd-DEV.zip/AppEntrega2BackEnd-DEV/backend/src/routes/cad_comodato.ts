/* eslint-disable prettier/prettier */
/* eslint-disable camelcase */
import { Router } from 'express';
import Cad_Comodato_Controller from '../controller/Cad_Comodato_Controller';

const cadComodatoRoutes = Router();

cadComodatoRoutes.get('/', Cad_Comodato_Controller.show);
cadComodatoRoutes.post('/pendencia', Cad_Comodato_Controller.pendencia);
cadComodatoRoutes.get('/pendencia', Cad_Comodato_Controller.listarPendencia);
cadComodatoRoutes.post('/devolucao', Cad_Comodato_Controller.devolucaoComodato);
cadComodatoRoutes.post(
  '/devolucao/filtro',
  Cad_Comodato_Controller.filtroDevolucao,
);
cadComodatoRoutes.get('/devolucao', Cad_Comodato_Controller.showDevolucao);
cadComodatoRoutes.patch('/devolucao/:id', Cad_Comodato_Controller.patch);

export default cadComodatoRoutes;
