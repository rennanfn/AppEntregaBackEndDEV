/* eslint-disable prettier/prettier */
/* eslint-disable camelcase */
import { Router } from 'express';
import Cad_Token_Controller from '../controller/Cad_Token_Controller';

const cadTokenRoutes = Router();

cadTokenRoutes.put('/:matricula', Cad_Token_Controller.update);
cadTokenRoutes.get('/:token', Cad_Token_Controller.validaToken);
cadTokenRoutes.patch('/', Cad_Token_Controller.ativaDesativa);

export default cadTokenRoutes;
