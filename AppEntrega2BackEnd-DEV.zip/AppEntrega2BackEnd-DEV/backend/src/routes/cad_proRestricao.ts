import { Router } from 'express';
import { CadProdRestricaoController } from '../controller/Cad_ProdRestricao_Controller';

const cadProdRestricaoRoutes = Router();

cadProdRestricaoRoutes.post(
  '/',
  CadProdRestricaoController.getProdutosSemRestricao,
);

export default cadProdRestricaoRoutes;
