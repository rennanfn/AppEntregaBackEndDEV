/* eslint-disable prettier/prettier */
/* eslint-disable camelcase */
import { Router } from 'express';
import Cad_Restricoes_Controller from '../controller/Cad_Restricoes_Controller';

const cadRestricoesRoutes = Router();

cadRestricoesRoutes.post('/', Cad_Restricoes_Controller.insert);
cadRestricoesRoutes.put('/', Cad_Restricoes_Controller.update);
cadRestricoesRoutes.get('/', Cad_Restricoes_Controller.show);
cadRestricoesRoutes.get('/:id', Cad_Restricoes_Controller.find);
// cadRestricoesRoutes.patch('/:id', Cad_Restricoes_Controller.patch);
cadRestricoesRoutes.patch('/', Cad_Restricoes_Controller.patch);

export default cadRestricoesRoutes;
