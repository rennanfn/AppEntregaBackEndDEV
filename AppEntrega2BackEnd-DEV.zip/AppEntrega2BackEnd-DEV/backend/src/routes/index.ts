/* eslint-disable prettier/prettier */
/* eslint-disable no-undef */
import { Router } from 'express';
import { validaToken } from '../utils/token';
import cadComodatoRoutes from './cad_comodato';
import cadMaxRetiradaRoutes from './cad_max_retirada';
import cadOperadorRoutes from './cad_operador';
import cadPeriodicidadeRoutes from './cad_periodicidade';
import cadProdutoRoutes from './cad_produto';
import { loginRoutes } from './login';
import cadAutorizadosRoutes from './cad_autorizados';
import cadRestricoesRoutes from './cad_restricoes';
import cadMovimentacaoRoutes from './cad_movimentacao';
import { HoneyPot } from '../utils/HoneyPot';
import cadProdRestricaoRoutes from './cad_proRestricao';
import cadColaboradoresRoutes from './cad_colaboradores';
import cadTokenRoutes from './cad_token_colaborador';

const routes = Router();

routes.use('/cadOperador', validaToken, cadOperadorRoutes);
routes.use('/login', loginRoutes);
routes.use('/cadPeriodo', validaToken, cadPeriodicidadeRoutes);
routes.use('/cadProduto', validaToken, cadProdutoRoutes);
routes.use('/cadMaxRetirada', validaToken, cadMaxRetiradaRoutes);
routes.use('/cadComodato', validaToken, cadComodatoRoutes);
routes.use('/cadAutorizados', validaToken, cadAutorizadosRoutes);
routes.use('/cadRestricoes', validaToken, cadRestricoesRoutes);
routes.use('/cadMovimentacao', validaToken, cadMovimentacaoRoutes);
routes.use('/cadProdutosSemRestricao', validaToken, cadProdRestricaoRoutes);
routes.use('/cadColaboradores', validaToken, cadColaboradoresRoutes);
routes.use('/cadToken', validaToken, cadTokenRoutes);


// *********************************************************
// * Qualquer outra tentativa de acesso vai cair no HoneyPot
// * Sempre deixar o honeyPot como últoma rota.
// *********************************************************
routes.all('/*', HoneyPot.reqGet);

export default routes;
