/* eslint-disable prettier/prettier */
/* eslint-disable camelcase */
import { Router } from 'express';
import Cad_Movimentacao_Controller from '../controller/Cad_Movimentacao_Controller';

const cadMovimentacaoRoutes = Router();

cadMovimentacaoRoutes.post('/', Cad_Movimentacao_Controller.insert);
cadMovimentacaoRoutes.get('/', Cad_Movimentacao_Controller.show);
cadMovimentacaoRoutes.post(
  '/filtro',
  Cad_Movimentacao_Controller.filtroMovimentacao,
);
// cadMovimentacaoRoutes.get('/:id', Cad_Movimentacao_Controller.find);
cadMovimentacaoRoutes.patch('/:id', Cad_Movimentacao_Controller.ativaDesativa);
// cadMovimentacaoRoutes.delete('/:id', Cad_Movimentacao_Controller.delete);

export default cadMovimentacaoRoutes;
