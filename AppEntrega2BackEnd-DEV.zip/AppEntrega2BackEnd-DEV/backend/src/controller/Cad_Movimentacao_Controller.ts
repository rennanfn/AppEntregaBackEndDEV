/* eslint-disable camelcase */
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
import { Request, Response } from 'express';
import { MySqlConnection } from '../model/MySqlConnection';
import { ErroGeneral } from '../model/ErroGeneral';
import CadMovimentacaoDB from '../modelDB/Cad_Movimentacao_DB';
import { buscaProdutosColabPodeRetirar } from '../utils/buscaProdutosColabPodeRetirar';
import retornoPadrao from '../utils/retornoPadrao';
import {
  FiltroMovimentacao,
  MovimentacaoInterface,
  MovimentacaoZ,
  movimentacaoSchema,
} from './../model/Cad_Movimentacao';

export default class MovimentacaoController {
  static async insert(req: Request, resp: Response): Promise<Response> {
    let movimentacao: MovimentacaoZ;
    const novaMovimentacao: MovimentacaoZ = [];
    try {
      movimentacao = movimentacaoSchema.parse(req.body);
      movimentacao.forEach(mov => {
        mov.data_retirada = new Date();
        mov.operador_id = req.customProperties.id;
        mov.leitura_qrcode = 1;
        novaMovimentacao.push(mov);
      });
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Objeto recebido não é do tipo esperado',
        error,
      );
      return resp.status(400).json(retornar);
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadMovimentacao = new CadMovimentacaoDB({} as MovimentacaoInterface);

    try {
      const prodsPodeRetirar = await buscaProdutosColabPodeRetirar(
        novaMovimentacao[0].colaborador_matricula,
        connection,
      );

      const naoDeveMovimentar = novaMovimentacao.some(mov => {
        const achouProduto = prodsPodeRetirar.produtos.find(
          prod => prod.id === mov.produto_id,
        );
        if (!achouProduto) return true;
        if (mov.qtde_retirada > achouProduto.qtd_max_retirada) return true;
        return false;
      });

      if (naoDeveMovimentar) {
        // Responde erro para o frontend e nao deixa gravar...
        return resp
          .status(400)
          .json(retornoPadrao(1, `Movimentação não permitida`));
      }

      const inserirMovimentacao = novaMovimentacao.map(mov => {
        return cadMovimentacao.insert(mov, connection);
      });
      const retorno = await Promise.all(inserirMovimentacao);
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao inserir movimentação`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async show(req: Request, resp: Response): Promise<Response> {
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }
    const cadMovimentacao = new CadMovimentacaoDB({});
    try {
      const retorno = await cadMovimentacao.show(connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async filtroMovimentacao(
    req: Request,
    resp: Response,
  ): Promise<Response> {
    const filtroParams: FiltroMovimentacao = req.body;

    if (typeof filtroParams === 'undefined') {
      return resp
        .status(400)
        .json(retornoPadrao(1, 'Objeto recebido não é do tipo esperado'));
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erroG = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erroG);
    }

    const cadFiltro = new CadMovimentacaoDB({});
    try {
      const retorno = await cadFiltro.filtroMovimentacao(
        filtroParams,
        connection,
      );
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao listar movimentações`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async ativaDesativa(req: Request, resp: Response): Promise<Response> {
    const { id } = req.params;
    const motivo = req.body.motivo;
    const desativado_em = new Date();

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadMovimentacao = new CadMovimentacaoDB({ id });
    try {
      const movimentacao = cadMovimentacao.ativaDesativa(
        id,
        desativado_em,
        motivo,
        connection,
      );
      await connection.commit();
      return resp.json(movimentacao);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar o produto`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }
}
