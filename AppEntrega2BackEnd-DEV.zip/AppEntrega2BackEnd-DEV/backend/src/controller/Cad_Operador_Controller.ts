/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/no-non-null-assertion */
/* eslint-disable valid-typeof */
/* eslint-disable no-undef */
// import operadorSchema from "./../model/Cad_Operador";
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
import { Request, Response } from 'express';
import { OperadorInterface, operadorSchema } from '../model/Cad_Operador';
import { MySqlConnection } from '../model/MySqlConnection';
import CadOperadorDB from '../modelDB/Cad_Operador_DB';
import Criptografar from '../utils/criptografar';
import retornoPadrao from '../utils/retornoPadrao';
import { ErroGeneral } from './../model/ErroGeneral';
import ShortUniqueId from 'short-unique-id';

export default class OperadorController {
  static async insert(req: Request, resp: Response): Promise<Response> {
    let operador: OperadorInterface = req.body;
    try {
      const { randomUUID } = new ShortUniqueId({
        dictionary: 'hex',
        length: 36,
      })
      operador.id = randomUUID();
      operador.criado_em = new Date();

      operadorSchema.parse(operador);
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Objeto recebido não é do tipo esperado',
        error,
      );
      return resp.status(400).json(retornar);
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadOperadorDB = new CadOperadorDB(operador);

    try {
      // Verifica no banco se já existe o login que está sendo cadastro. Logins iguais não são permitidos
      const operadorDB = await cadOperadorDB.findLogin(
        operador.login!,
        connection,
      );

      if (operadorDB.length >= 1) {
        return resp
          .status(400)
          .json(
            retornoPadrao(
              1,
              `Já existe um login '${operador.login}'. Cadastre um login diferente`,
            ),
          );
      }

      let senhaCrip;
      if (typeof operador.senha !== 'undefined') {
        if (operador.senha !== null) {
          senhaCrip = await Criptografar.criptografarSenha(operador.senha);
          operador.senha = senhaCrip;
        }
      }

      const retorno = await cadOperadorDB.insert(operador, connection);
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao inserir operador: ${operador.login}`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async update(req: Request, resp: Response): Promise<Response> {
    let operador: OperadorInterface;
    // Se durante a edição não houver alteração de senha, o front envia o campo senha como null, o que não é permitido no back
    // Por isso foi feito esta tratativa, para que caso a senha recebida do front esteja como null o back remove o campo senha do objeto
    // E envia o objeto sem senha para o banco.
    if (req.body.senha === null) {
      delete req.body.senha;
    }

    try {
      operador = operadorSchema.parse(req.body);
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Objeto recebido não é do tipo esperado',
        error,
      );
      return resp.status(400).json(retornar);
    }
    if (typeof operador === 'undefined') {
      return resp
        .status(400)
        .json(retornoPadrao(1, 'Objeto recebido não é do tipo esperado'));
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com oracle',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadOperador = new CadOperadorDB(operador);
    try {
      let senhaCrip;
      if (typeof operador.senha !== 'undefined') {
        if (operador.senha !== null) {
          senhaCrip = await Criptografar.criptografarSenha(operador.senha);
          operador.senha = senhaCrip;
        }
      }

      const retorno = await cadOperador.update(operador, connection);
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar operador`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async show(req: Request, resp: Response): Promise<Response> {
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }
    const cadOperador = new CadOperadorDB({});
    try {
      const retorno = await cadOperador.show(connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async find(req: Request, resp: Response): Promise<Response> {
    const { id } = req.params;

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com oracle',
        error,
      );
      return resp.status(400).json(erro);
    }

    const cadOperador = new CadOperadorDB({ id });
    try {
      const retorno = await cadOperador.find(String(id), connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async ativaDesativa(req: Request, resp: Response): Promise<Response> {
    const { id } = req.params;

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com oracle',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadOperador = new CadOperadorDB({ id });
    try {
      const operador = await cadOperador.findAtivaDesativa(id, connection);
      if (typeof operador === 'undefined') {
        return resp
          .status(400)
          .json(retornoPadrao(1, 'Operador não encontrado '));
      }

      if (operador[0].desativado_em === null) {
        operador[0].desativado_em = new Date();
      } else {
        operador[0].desativado_em = undefined;
      }

      cadOperador.ativaDesativa(operador[0], connection);
      await connection.commit();
      return resp.json(operador);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar operador `,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }
}
