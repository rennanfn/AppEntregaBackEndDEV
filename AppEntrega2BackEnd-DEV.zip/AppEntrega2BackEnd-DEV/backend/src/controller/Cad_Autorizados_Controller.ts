/* eslint-disable no-new */
/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable prettier/prettier */
import { Request, Response } from 'express';
import { autorizadosSchema, iAutorizados } from '../model/Cad_Autorizados';
import { ErroGeneral } from '../model/ErroGeneral';
import CadAutorizadosDB from '../modelDB/Cad_Autorizados_BD';
import retornoPadrao from '../utils/retornoPadrao';
import { MySqlConnection } from '../model/MySqlConnection';
import { convertDate2String, convertString2Date } from '../utils/dateNow';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import { RowDataPacket } from 'mysql2/promise';
import { CadColaboradorDB } from '../modelDB/Cad_Colaborador_DB';
import { iColaboradorInfo } from '../model/Cad_Colaborador';

export default class AutorizadosController {
  static async insert(req: Request, resp: Response): Promise<Response> {
    const autorizados: iAutorizados = req.body;
    try {
     autorizados.data_nascto = convertString2Date(autorizados.data_nascto as string);
     autorizadosSchema.parse(autorizados);
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Objeto recebido não é do tipo esperado',
        error,
      );
      return resp.status(400).json(retornar);
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }
    const cadAutorizados = new CadAutorizadosDB();
    const cadColaboradores = new CadColaboradorDB();
    try {
      // Verifica na tabela CDC_AUTORIZADOS_TAB qual é o último número de matrícula cadastrado
    // O obj.matricula recebe este valor e soma 1, atribuindo o resultado desta soma ao novo cadastro
    const addMatricula = await connection.query(
      `SELECT max (matricula) as maxMat from app_entrega_autorizados`,
    );
    if (!addMatricula) {
      consoleLog(`Erro ao buscar matrícula, rows = undefined`, pVerbose.erro);
    } else {
      const result = addMatricula.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
        } as RowDataPacket
      });
      const maxMatricula = addMatricula[0];
      const objmatricula = maxMatricula[0].maxMat;
      autorizados.matricula = objmatricula + 1;
    }
      const retorno = await cadAutorizados.insert(autorizados, connection);

      const colaborador: iColaboradorInfo = {
        matricula: autorizados.matricula as number,
        nome_funcio: autorizados.nome,
        data_nascto: convertDate2String(autorizados.data_nascto),
        desc_sexo: autorizados.sexo === 'F' ? 'FEMININO' : autorizados.sexo === 'M' ? 'MASCULINO' : '',
        internoouexterno: 'E',
        desc_situacao: 'Ativo',
        data_admissao: ''
      }

      await cadColaboradores.insert(colaborador, connection);
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao inserir colaborador autorizado ${autorizados.matricula}`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async update(req: Request, resp: Response): Promise<Response> {
    const autorizados: iAutorizados = req.body;
    try {
      autorizados.data_nascto = convertString2Date(autorizados.data_nascto as string);
      autorizadosSchema.parse(autorizados);
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Objeto recebido não é do tipo esperado',
        error,
      );
      return resp.status(400).json(retornar);
    }

    if (typeof autorizados === 'undefined') {
      return resp
        .status(400)
        .json(retornoPadrao(1, 'Objeto recebido não é do tipo esperado'));
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadAutorizados = new CadAutorizadosDB();
    const cadColaborador = new CadColaboradorDB();
    try {
      const retorno = await cadAutorizados.update(autorizados, connection);

      const colaborador: iColaboradorInfo = {
        matricula: autorizados.matricula as number,
        nome_funcio: autorizados.nome,
        data_nascto: convertDate2String(autorizados.data_nascto),
        desc_sexo: autorizados.sexo === 'F' ? 'FEMININO' : autorizados.sexo === 'M' ? 'MASCULINO' : '',
        internoouexterno: 'E',
        desc_situacao: 'Ativo',
        data_admissao: ''
      }

      await cadColaborador.update(colaborador, connection);

      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar o colaborador autorizado ${autorizados.matricula}`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async show(req: Request, resp: Response): Promise<Response> {
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }
    const cadAutorizados = new CadAutorizadosDB();
    try {
      const retorno = await cadAutorizados.show(connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async find(req: Request, resp: Response): Promise<Response> {
    const { matricula } = req.params;

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }

    const cadAutorizados = new CadAutorizadosDB();
    try {
      const retorno = await cadAutorizados.find(Number(matricula), connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async buscarTokenAut(req: Request, resp: Response): Promise<Response> {
    const { matricula } = req.params;

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }

    const cadToken = new CadAutorizadosDB();
    try {
      const retorno = await cadToken.buscarTokenAut(Number(matricula), connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async ativaDesativa(req: Request, resp: Response): Promise<Response> {
    const { matricula } = req.params;

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com oracle',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadAutorizados = new CadAutorizadosDB();
    const cadColaborador = new CadColaboradorDB();
    try {
      const autorizado = await cadAutorizados.findAtivaDesativa(
        Number(matricula),
        connection,
      );
      if (typeof autorizado === 'undefined') {
        return resp
          .status(400)
          .json(retornoPadrao(1, 'Colaborador não encontrado'));
      }

      if (autorizado[0].situacao === 1) {
        autorizado[0].situacao = 0;
      } else {
        autorizado[0].situacao = 1;
      }

      await cadAutorizados.ativaDesativa(autorizado[0].situacao, Number(autorizado[0].matricula), connection);


      // Desativando dentro da tabela de colaboradores
      const colaborador = await cadColaborador.findAtivaDesativa(Number(autorizado[0].matricula), connection);

      if (typeof colaborador === 'undefined') {
        return resp
          .status(400)
          .json(retornoPadrao(1, 'Colaborador não encontrado'));
      }

      if (colaborador.desativado_em === null) {
        colaborador.desativado_em = new Date();
      } else {
        colaborador.desativado_em = null;
      }

      if (colaborador.desc_situacao === 'Ativo') {
        colaborador.desc_situacao = 'Desativado';
      } else {
        colaborador.desc_situacao = 'Ativo';
      }

      await cadColaborador.patch(colaborador, connection)

      await connection.commit();
      return resp.json(autorizado);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar colaborador`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async delete(req: Request, resp: Response): Promise<Response> {
    const { matricula } = req.params;

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }
    const cadAutorizados = new CadAutorizadosDB();
    try {
      const retorno = await cadAutorizados.delete(
        Number(matricula),
        connection,
      );
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao deletar colaborador autorizado ${matricula}`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }
}
