import { Request, Response } from 'express';
import retornoPadrao from '../utils/retornoPadrao';
import { iProdSemRestricao } from '../model/Cad_ProdRestricao';
import { buscaProdutosColabPodeRetirar } from '../utils/buscaProdutosColabPodeRetirar';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import { QrCode } from '../utils/qrCode';
import { ErroGeneral } from '../model/ErroGeneral';
import { MySqlConnection } from '../model/MySqlConnection';

export interface iProdutosPodeRetirar {
  produtos: iProdSemRestricao[];
}

export class CadProdRestricaoController {
  static async getProdutosSemRestricao(req: Request, resp: Response) {
    const { qrcode } = req.body as { qrcode: string };
    if (!qrcode) {
      return resp.status(400).json(retornoPadrao(1, `Falta QrCode`));
    }
    // Pega o conteúdo do QrCode para poder pegar a matrícula
    const qrCodePayload = QrCode.getQrCodePayload(qrcode);
    if (!qrCodePayload) {
      return resp
        .status(500)
        .json(
          retornoPadrao(
            1,
            `QrCode inválido, entre em contato com o administrador do sistema`,
          ),
        );
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }
    try {
      const prodSemRestricao = await buscaProdutosColabPodeRetirar(
        qrCodePayload.matricula,
        connection,
      );
      return resp.json(prodSemRestricao);
    } catch (error) {
      consoleLog(error, pVerbose.erro);
      return resp
        .status(400)
        .json(
          retornoPadrao(
            1,
            `Erro ao tentar buscar os produtos disponíveis para a matrícula ${qrCodePayload.matricula}`,
          ),
        );
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }
}
