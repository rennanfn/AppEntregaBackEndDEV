/* eslint-disable object-shorthand */
/* eslint-disable no-unused-expressions */
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
import { Request, Response } from 'express';
import { ErroGeneral } from '../model/ErroGeneral';
import CadTokenDB from '../modelDB/Cad_Token_DB';
import retornoPadrao from '../utils/retornoPadrao';
import { MySqlConnection } from '../model/MySqlConnection';
import { gerarTokenColaborador } from '../utils/token';
import { TokenInterface } from '../model/Cad_Token';

export default class TokenController {
  static async update(req: Request, resp: Response): Promise<Response> {
    const { matricula } = req.params;

    if (typeof matricula === 'undefined') {
      return resp
        .status(400)
        .json(retornoPadrao(1, 'Objeto recebido não é do tipo esperado!'));
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadToken = new CadTokenDB({});
    try {
      const verificaToken = await cadToken.verificaToken(
        Number(matricula),
        connection,
      );
      if (typeof verificaToken === 'undefined') {
        return resp.status(400).json(retornoPadrao(1, 'Token undefined'));
      }
      if (verificaToken.length > 0) {
        const lastToken = verificaToken[0];
        const sequencial = lastToken.sequencial ? lastToken.sequencial + 1 : 1;
        const token = gerarTokenColaborador({
          matricula: Number(matricula),
          token: '',
          sequencial: sequencial,
        });
        const desativado = 0;

        await cadToken.update(
          Number(matricula),
          Number(sequencial),
          token,
          desativado,
          connection,
        );
        await connection.commit();
        return resp.status(200).json({ token });
      } else {
        const sequencial = 1;
        const token = gerarTokenColaborador({
          matricula: Number(matricula),
          token: '',
          sequencial: sequencial,
        });
        const desativado = 0;

        await cadToken.update(
          Number(matricula),
          Number(sequencial),
          token,
          desativado,
          connection,
        );
        await connection.commit();
        return resp.status(200).json({ token });
      }
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar token do colaborador`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async validaToken(req: Request, resp: Response): Promise<Response> {
    const { token } = req.params;
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }
    const cadToken = new CadTokenDB({});
    try {
      const retorno = await cadToken.validaToken(token, connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro na leitura do QrCode`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async addTokensNewFunc(
    req: Request,
    resp: Response,
  ): Promise<Response> {
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }
    const cadToken = new CadTokenDB({});
    try {
      const retorno = await cadToken.generatorTokensNewFunc();
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        'Erro ao inserir token',
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async ativaDesativa(req: Request, resp: Response): Promise<Response> {
    const id: TokenInterface = req.body;
    const idArray = Array.isArray(id) ? id : [id];

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadToken = new CadTokenDB({});
    try {
      const tokens: TokenInterface[] = [];
      for (const itemId of idArray) {
        const token = await cadToken.findAtivaDesativa(itemId.id, connection);
        tokens.push(...token);
      }

      if (typeof tokens === 'undefined') {
        return resp
          .status(400)
          .json(retornoPadrao(1, 'Token não encontrado'));
      }

      const desativarToken = tokens.map(token => {
        if (token.desativado === 0) {
          token.desativado = 1;
        } else {
          token.desativado = 0;
        }
        return token;
      });

      const desativar = desativarToken.map(token =>
        cadToken.ativaDesativa(token, connection),
      );

      await Promise.all(desativar);
      await connection.commit();
      return resp.json(retornoPadrao(0, `Token atualizado com sucesso!`));
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar a token`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }
}
