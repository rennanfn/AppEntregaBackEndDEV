/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
import { Request, Response } from 'express';
import {
  RestricoesInterface,
  restricoesSchema
} from '../model/Cad_Restricoes';
import { ErroGeneral } from '../model/ErroGeneral';
import { MySqlConnection } from '../model/MySqlConnection';
import CadRestricoesDB from '../modelDB/Cad_Restricoes_DB';
import retornoPadrao from '../utils/retornoPadrao';
import ShortUniqueId from 'short-unique-id';

export default class RestricoesController {
  static async insert(req: Request, resp: Response): Promise<Response> {
    let restricoes;
    try {
      const { randomUUID } = new ShortUniqueId({
        dictionary: 'hex',
        length: 32,
      });

      restricoes = req.body.map((restricoes: RestricoesInterface) => {
        restricoes.id = randomUUID();
        const restricoesMap = restricoesSchema.parse(restricoes);
        return restricoesMap;
      });

    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Objeto recebido não é do tipo esperado',
        error,
      );
      return resp.status(400).json(retornar);
    }
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadRestricoes = new CadRestricoesDB(restricoes);
    try {
      const insert = restricoes.map(rest =>
        cadRestricoes.insert(rest, connection),
      );
      const retorno = await Promise.all(insert);
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao inserir restrição ${restricoes.id}`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async update(req: Request, resp: Response): Promise<Response> {
    let restricoes: RestricoesInterface;
    try {
      restricoes = restricoesSchema.parse(req.body);
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Objeto recebido não é do tipo esperado',
        error,
      );
      return resp.status(400).json(retornar);
    }
    if (typeof restricoes === 'undefined') {
      return resp
        .status(400)
        .json(retornoPadrao(1, 'Objeto recebido não é do tipo esperado!'));
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadRestricoes = new CadRestricoesDB({});
    try {
      const retorno = await cadRestricoes.update(restricoes, connection);
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar restrição ${restricoes.id}`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async patch(req: Request, resp: Response): Promise<Response> {
    const id: RestricoesInterface = req.body;
    const idArray = Array.isArray(id) ? id : [id];

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadRestricoes = new CadRestricoesDB({});
    try {
      const restricoes: RestricoesInterface[] = [];
      for (const itemId of idArray) {
        const restricao = await cadRestricoes.findPatch(itemId, connection);
        restricoes.push(...restricao);
      }

      if (typeof restricoes === 'undefined') {
        return resp
          .status(400)
          .json(retornoPadrao(1, 'Restrição não encontrada'));
      }

      const desativarRestricao = restricoes.map(restricao => {
        if (restricao.desativado_em === null) {
          restricao.desativado_em = new Date();
        } else {
          restricao.desativado_em = null;
        }
        return restricao;
      });

      const desativar = desativarRestricao.map(restricao =>
        cadRestricoes.patch(restricao, connection),
      );

      await Promise.all(desativar);
      await connection.commit();
      return resp.json(restricoes);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar a restrição`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async show(req: Request, resp: Response): Promise<Response> {
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }
    const cadRestricoes = new CadRestricoesDB({});
    try {
      const retorno = await cadRestricoes.show(connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async find(req: Request, resp: Response): Promise<Response> {
    const { id } = req.params;

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }

    const cadRestricoes = new CadRestricoesDB({});
    try {
      const retorno = await cadRestricoes.find(id, connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }
}
