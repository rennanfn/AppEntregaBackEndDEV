/* eslint-disable camelcase */
/* eslint-disable prettier/prettier */
import {
  CadMaxRetiradaOut,
  MaxRetiradaInterface,
  MaxRetiradaZ,
  maxRetiradaSchema,
  maxRetiradaSchemaHttpArray,
} from './../model/Cad_Max_Retirada';
import { Request, Response } from 'express';
import CadMaxRetiradaDB from '../modelDB/Cad_Max_Retirada_DB';
import retornoPadrao from '../utils/retornoPadrao';
import { ErroGeneral } from './../model/ErroGeneral';
import { ZodError } from 'zod';
import { ReturnDefault } from '../Interfaces';
import { convertDateTime2String } from '../utils/dateNow';
import { MySqlConnection } from '../model/MySqlConnection';

export default class MaxRetiradaController {
  static async insert(req: Request, resp: Response): Promise<Response> {
    const maxRetiradaHttp = maxRetiradaSchemaHttpArray.parse(req.body);

    const maxRetiradasNovo = maxRetiradaHttp.reduce<MaxRetiradaZ[]>(
      (acc, atual) => {
        const retiradas = atual.produtos.reduce<MaxRetiradaZ[]>(
          (prodAcc, prodAtual) => {
            prodAcc.push({
              matricula: atual.matricula,
              produto_id: prodAtual.produto_id,
              qtd_max_retirada: prodAtual.qtd_max_retirada,
              criado_em: convertDateTime2String(new Date()),
              periodo_liberado_retirada_ini:
                prodAtual.periodo_liberado_retirada_ini,
              periodo_liberado_retirada_fim:
                prodAtual.periodo_liberado_retirada_fim,
            });
            return prodAcc;
          },
          [],
        );
        acc.push(...retiradas);
        return acc;
      },
      [],
    );

    let maxRetirada;
    try {
      maxRetirada = maxRetiradasNovo.map(maxRetirada => {
        const maxRetiradaMap = maxRetiradaSchema.parse(maxRetirada);
        return maxRetiradaMap;
      });
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Objeto recebido não é do tipo esperado',
        error,
      );
      return resp.status(400).json(retornar);
    }
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }
    const cadMaxRetirada = new CadMaxRetiradaDB({} as MaxRetiradaInterface);
    try {
      // Verifica no banco se já existe uma liberação de um determinado produto para um determinado colaborador
      // Lembrando que o colaborador pode retirar n produtos e n quantidade destes produtos
      // Porém não pode ter mais de um cadastro de retirada para o mesmo produto no periodo já existente
      const promisesMaxRet: Promise<CadMaxRetiradaOut[]>[] = [];
      maxRetirada.forEach(element => {
        promisesMaxRet.push(
          cadMaxRetirada.verificaMaxRetirada(element, connection),
        );
      });
      const maxRetiradaDB = await Promise.all(promisesMaxRet);

      if (
        Array.isArray(maxRetiradaDB) &&
        maxRetiradaDB.some(arr => Array.isArray(arr) && arr.length > 0)
      ) {
        const retorno: ReturnDefault[] = [];
        maxRetiradaDB.forEach(retirada => {
          retorno.push(
            retornoPadrao(
              1,
              `Já existe uma retirada para o colaborador: ${retirada[0].matricula} do produto: ${retirada[0].prod_descricao}`,
            ),
          );
        });
        return resp.status(400).json(retorno);
      }
      // const retorno = await cadMaxRetirada.insert(maxRetirada, connection);
      const insert = maxRetirada.map(maxRet =>
        cadMaxRetirada.insert(maxRet, connection),
      );
      await Promise.all(insert);
      await connection.commit();
      return resp.json([retornoPadrao(0, `Retiradas cadastradas com sucesso`)]);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao inserir máx. retirada`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async update(req: Request, resp: Response): Promise<Response> {
    let maxRetirada;
    try {
      maxRetirada = maxRetiradaSchema.parse(req.body);
    } catch (error) {
      if (error instanceof ZodError) {
        const mensagem = error.issues[0]?.message || 'Erro ao validar dados';
        const retornar = { error: mensagem };
        return resp.status(400).json(retornar);
      }
    }
    if (typeof maxRetirada === 'undefined') {
      return resp
        .status(400)
        .json(retornoPadrao(1, 'Objeto recebido não é do tipo esperado!'));
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadMaxRetirada = new CadMaxRetiradaDB({});
    try {
      const retorno = await cadMaxRetirada.update(maxRetirada, connection);
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar máx. retirada do colaborador ${maxRetirada.matricula}`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async show(req: Request, resp: Response): Promise<Response> {
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }
    const cadMaxRetirada = new CadMaxRetiradaDB({});
    try {
      const retorno = await cadMaxRetirada.show(connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async find(req: Request, resp: Response): Promise<Response> {
    const { matricula } = req.params;

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }

    const cadMaxRetirada = new CadMaxRetiradaDB({});
    try {
      const retorno = await cadMaxRetirada.find(Number(matricula), connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async delete(req: Request, resp: Response): Promise<Response> {
    const matricula: MaxRetiradaInterface = req.body;
    if (!Array.isArray(matricula)) {
      return resp
        .status(400)
        .json(retornoPadrao(1, 'Objeto recebido não é do tipo esperado'));
    }
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }
    const cadMaxRetirada = new CadMaxRetiradaDB({});
    try {
      const deletar = matricula.map(matricula =>
        cadMaxRetirada.delete(matricula, connection),
      );
      const retorno = await Promise.all(deletar);
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao deletar retirada do colaborador ${matricula}`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }
}
