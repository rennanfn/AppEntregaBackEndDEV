/* eslint-disable dot-notation */
/* eslint-disable prettier/prettier */
import { Request, Response } from 'express';
import { Connection } from 'mysql2/promise';
import { OperadorInterface } from '../model/Cad_Operador';
import { MySqlConnection } from '../model/MySqlConnection';
import CadOperadorDB from '../modelDB/Cad_Operador_DB';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import Criptografar from '../utils/criptografar';
import retornoPadrao from '../utils/retornoPadrao';
import { gerarToken, getDataToRefresh } from '../utils/token';
import { Token } from './../Interfaces/index';
import { ErroGeneral } from './../model/ErroGeneral';

export class LoginController {
  static async autenticar(req: Request, resp: Response): Promise<Response> {
    const operador: OperadorInterface = req.body;

    if (
      typeof operador.login === 'undefined' ||
      typeof operador.senha === 'undefined'
    ) {
      return resp
        .status(400)
        .json(retornoPadrao(1, 'Objeto recebido não é do tipo esperado!'));
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retorno = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retorno);
    }

    const cadOperador = new CadOperadorDB(operador);
    try {
      const operadorDB = await cadOperador.findLogin(
        operador.login,
        connection,
      );

      if (operadorDB.length === 0) {
        return resp
          .status(400)
          .json(retornoPadrao(1, `Login ou senha inválido`));
      }

      if (
        typeof operadorDB[0].senha === 'undefined' ||
        operadorDB[0].senha === null
      ) {
        return resp
          .status(400)
          .json(retornoPadrao(1, `Login ou senha inválido`));
      }

      if (operadorDB[0].desativado_em !== '') {
        return resp
          .status(400)
          .json(
            retornoPadrao(1, `Não é possível autenticar. Operador desativado!`),
          );
      }

      const senhasConferem = await Criptografar.compararSenhas(
        operador.senha,
        operadorDB[0].senha,
      );

      if (!senhasConferem) {
        return resp
          .status(400)
          .json(retornoPadrao(1, `Login ou senha inválido!`));
      }

      const origem = (req.headers['Origin'] = req.headers.origin);
      if (
        operadorDB[0].gerenciador === 1 &&
        origem === process.env.ORIGIN_GERENCIADOR
      ) {
        const dadosToken = await LoginController.prepararToken(
          operadorDB[0],
          connection,
        );
        const token = gerarToken(dadosToken);
        if (token === '') {
          return resp.status(400).json(retornoPadrao(1, `Erro ao gerar token`));
        }
        return resp.status(200).json({ token });
      }

      if (operadorDB[0].mobile === 1 && origem === process.env.ORIGIN_APP) {
        const dadosToken = await LoginController.prepararToken(
          operadorDB[0],
          connection,
        );
        const token = gerarToken(dadosToken);
        if (token === '') {
          return resp.status(400).json(retornoPadrao(1, `Erro ao gerar token`));
        }
        return resp.status(200).json({ token });
      }

      consoleLog(`Erro ao autenticar operador`, pVerbose.erro);
      return resp
        .status(400)
        .json(retornoPadrao(1, `Erro ao autenticar operador`));
    } catch (error) {
      await connection.rollback();
      const retorno = ErroGeneral.getErrorGeneral(
        'Erro ao autenticar operador',
        error,
      );
      return resp.status(400).json(retorno);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async prepararToken(
    operadorDB: OperadorInterface,
    conn: Connection,
  ): Promise<Token> {
    const cadOperador = new CadOperadorDB({});

    if (typeof operadorDB.login === 'undefined' || operadorDB.login === null) {
      return {} as Token;
    }
    const operadorLogin = await cadOperador.findLogin(operadorDB.login, conn);

    const dadosToken: Token = {
      id: String(operadorLogin[0].id),
      nome:
        typeof operadorLogin[0].nome !== 'undefined'
          ? operadorLogin[0].nome
          : '',
      login:
        typeof operadorLogin[0].login !== 'undefined'
          ? operadorLogin[0].login
          : '',
    };
    return dadosToken;
  }

  static async refreshtoken(req: Request, resp: Response): Promise<Response> {
    // Verifica se o token recebido é valido
    const token = req.headers.authorization;
    if (typeof token === 'undefined') {
      consoleLog(`Request sem token, cancelado refresh token`, pVerbose.erro);
      return resp
        .status(403)
        .json(
          retornoPadrao(
            1,
            `Sessão Expirada. Realize novamente a autenticação.`,
          ),
        );
    }
    const dataToken = getDataToRefresh(token);
    if (!dataToken) {
      return resp
        .status(403)
        .json(
          retornoPadrao(
            1,
            `Sessão Expirada. Realize novamente a autenticação.`,
          ),
        );
    }

    // Começa a buscar os dados do usuario para criar o novo token
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retorno = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retorno);
    }

    try {
      consoleLog(`Validando login - RefreshToken ${dataToken.login}`, pVerbose.aviso);
      const cadOperador = new CadOperadorDB({});
      const operadorBD = await cadOperador.findLogin(
        dataToken.login,
        connection,
      );

      if (operadorBD.length === 0) {
        consoleLog(`Login informado ${dataToken.login} não encontrado `, pVerbose.erro);
        return resp
          .status(400)
          .json(retornoPadrao(1, `Erro ao tentar atualizar token`));
      }

      const dadosToken = await LoginController.prepararToken(
        operadorBD[0],
        connection,
      );

      const tokenNovo = gerarToken(dadosToken);
      if (tokenNovo === '') {
        return resp.status(400).json(retornoPadrao(1, `Erro ao gerar token`));
      }
      return resp.status(200).json({ token: tokenNovo });
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        'Erro ao atualizar token',
        error,
      );
      return resp.status(400).json(resultErro);

      // return resp.status(400).json(error);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }
}
