/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable camelcase */
/* eslint-disable prettier/prettier */
import { ErroGeneral } from './../model/ErroGeneral';
import { Request, Response } from 'express';
import CadComodatoDB, {
  iDevolucaoComodato,
  iTotalComodatoFaltaDevolver,
} from '../modelDB/Cad_Comodato_DB';
import retornoPadrao from '../utils/retornoPadrao';
import { QrCode } from '../utils/qrCode';
import { FiltroDevolucao } from '../model/Cad_Comodato';
import { MySqlConnection } from '../model/MySqlConnection';

export default class ComodatoController {
  static async show(req: Request, resp: Response): Promise<Response> {
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }

    const cadComodato = new CadComodatoDB({});
    try {
      const retorno = await cadComodato.show(connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async pendencia(req: Request, resp: Response): Promise<Response> {
    const { qrcode } = req.body as { qrcode: string };
    if (!qrcode) {
      return resp.status(400).json(retornoPadrao(1, `Falta QrCode`));
    }
    // Pega o conteúdo do QrCode para poder pegar a matrícula
    const qrCodePayload = QrCode.getQrCodePayload(qrcode);
    if (!qrCodePayload) {
      return resp
        .status(500)
        .json(
          retornoPadrao(
            1,
            `QrCode inválido, entre em contato com o administrador do sistema`,
          ),
        );
    }
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }

    try {
      const cadComodatoDB = new CadComodatoDB({});
      // Busca a quantidade de todos os comodatos que o colaborador retirou desde quando entrou na empresa agrupando por produto;
      const totalRetirados = await cadComodatoDB.getTotalComodatoRetirado(
        connection,
        qrCodePayload.matricula,
      );
      // Busca a quantidade de todos os comodatos que o colaborador DEVOLVEU agrupando por produto;
      const totalDevolvidos = await cadComodatoDB.getTotalComodatoDevolvido(
        connection,
        qrCodePayload.matricula,
      );
      const faltaDevolver: iTotalComodatoFaltaDevolver[] = [];
      totalRetirados.forEach(retirado => {
        const devolvido = totalDevolvidos.find(
          dev => dev.produto_id === retirado.produto_id,
        );
        if (typeof devolvido === 'undefined') {
          // Se não encontrou esse item nos devolvidos então falta ele devolver tudo;
          faltaDevolver.push({
            colaborador_matricula: retirado.colaborador_matricula,
            nome_funcio: retirado.nome_funcio,
            produto_id: retirado.produto_id,
            prod_descricao: retirado.prod_descricao,
            qtd_falta_devolver: retirado.qtd_total_retirada,
          });
          return;
        }
        if (retirado.qtd_total_retirada > devolvido.qtd_total_devolvida) {
          // Se ele ainda não devolveu tudo, então manda só a quantidade que falta devolver
          faltaDevolver.push({
            colaborador_matricula: retirado.colaborador_matricula,
            nome_funcio: retirado.nome_funcio,
            produto_id: retirado.produto_id,
            prod_descricao: retirado.prod_descricao,
            qtd_falta_devolver:
              retirado.qtd_total_retirada - devolvido.qtd_total_devolvida,
          });
        }
      });
      return resp.json(faltaDevolver);
    } catch (error) {
      const retornto = ErroGeneral.getErrorGeneral(
        `Erro ao tentar buscar os comodatos pendentes do colaborador ${qrCodePayload.matricula}`,
        error,
      );
      return resp.status(400).json(retornto);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async listarPendencia(
    req: Request,
    resp: Response,
  ): Promise<Response> {
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }

    const cadComodato = new CadComodatoDB({});
    try {
      //  const retorno = await cadComodato.showPendencia(connection);

      // return resp.json(retorno);
      // Busca a quantidade de todos os comodatos que o colaborador retirou desde quando entrou na empresa agrupando por produto;
      const totalRetirados = await cadComodato.getTotalComodatoRetirado(
        connection,
      );
      if (totalRetirados.length <= 0) {
        // Se ele não retirou nenhum comodato até hoje então retorna que ele não tem pendencias;

        return resp.json({});
      }
      // Busca a quantidade de todos os comodatos que o colaborador DEVOLVEU agrupando por produto;
      const totalDevolvidos = await cadComodato.getTotalComodatoDevolvido(
        connection,
      );
      const faltaDevolver: iTotalComodatoFaltaDevolver[] = [];
      totalRetirados.forEach(retirado => {
        // Procura nos itens devolvidos se esse colaborador já devolveu esse produto alguma vez.
        const devolvido = totalDevolvidos.find(dev => {
          if (
            dev.produto_id === retirado.produto_id &&
            dev.colaborador_matricula === retirado.colaborador_matricula
          ) {
            return true;
          }
          return false;
        });

        if (typeof devolvido === 'undefined') {
          // Se não encontrou esse item nos devolvidos então falta ele devolver tudo;
          faltaDevolver.push({
            colaborador_matricula: retirado.colaborador_matricula,
            nome_funcio: retirado.nome_funcio,
            produto_id: retirado.produto_id,
            prod_descricao: retirado.prod_descricao,
            qtd_falta_devolver: retirado.qtd_total_retirada,
          });
          return;
        }
        if (retirado.qtd_total_retirada > devolvido.qtd_total_devolvida) {
          // Se ele ainda não devolveu tudo, então manda só a quantidade que falta devolver
          faltaDevolver.push({
            colaborador_matricula: retirado.colaborador_matricula,
            nome_funcio: retirado.nome_funcio,
            produto_id: retirado.produto_id,
            prod_descricao: retirado.prod_descricao,
            qtd_falta_devolver:
              retirado.qtd_total_retirada - devolvido.qtd_total_devolvida,
          });
        }
      });
      return resp.json(faltaDevolver);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async devolucaoComodato(
    req: Request,
    resp: Response,
  ): Promise<Response> {
    const devolucao = req.body.map((devolucao: any) => {
      const devolucaoMap = {
        ...devolucao,
        data_devolucao: new Date(),
        operador_id: req.customProperties.id,
      };
      return devolucaoMap;
    });

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadDevolucao = new CadComodatoDB(devolucao);
    try {
      const insertDevolucao = devolucao.map((dev: iDevolucaoComodato) =>
        cadDevolucao.devolucaoComodato(dev, connection),
      );
      const retorno = await Promise.all(insertDevolucao);
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      await connection.roolback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao inserir devolução ${devolucao.id}`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async showDevolucao(req: Request, resp: Response): Promise<Response> {
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }

    const cadComodato = new CadComodatoDB({});
    try {
      const retorno = await cadComodato.showDevolucao(connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async filtroDevolucao(
    req: Request,
    resp: Response,
  ): Promise<Response> {
    const filtroParams: FiltroDevolucao = req.body;

    if (typeof filtroParams === 'undefined') {
      return resp
        .status(400)
        .json(retornoPadrao(1, 'Objeto recebido não é do tipo esperado'));
    }

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erroG = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erroG);
    }

    const cadFiltro = new CadComodatoDB({});
    try {
      const retorno = await cadFiltro.filtroDevolucao(filtroParams, connection);
      await connection.commit();
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao listar devoluções`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async patch(req: Request, resp: Response): Promise<Response> {
    const { id } = req.params;
    const motivo = req.body.motivo;
    const desativado_em = new Date();

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadDevolucao = new CadComodatoDB({});
    try {
      const devolucao = cadDevolucao.patch(
        id,
        desativado_em,
        motivo,
        connection,
      );
      await connection.commit();
      return resp.json(devolucao);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar devolução`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }
}
