/* eslint-disable prettier/prettier */
import { Request, Response } from 'express';
import { CadColaboradorDB } from '../modelDB/Cad_Colaborador_DB';
import { ErroGeneral } from '../model/ErroGeneral';
import { MySqlConnection } from '../model/MySqlConnection';
import retornoPadrao from '../utils/retornoPadrao';
import { iColaboradorInfo } from '../model/Cad_Colaborador';
import CadAutorizadosDB from '../modelDB/Cad_Autorizados_BD';

export default class ColaboradorController {
  static async show(req: Request, resp: Response): Promise<Response> {
    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }

    const cadColaborador = new CadColaboradorDB();
    try {
      const retorno = await cadColaborador.showColaborador(connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async buscarToken(req: Request, resp: Response): Promise<Response> {
    const { matricula } = req.params;

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const erro = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(erro);
    }

    const cadToken = new CadColaboradorDB();
    try {
      const retorno = await cadToken.buscarToken(Number(matricula), connection);
      return resp.json(retorno);
    } catch (error) {
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao buscar parâmetros`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }

  static async ativaDesativa(req: Request, resp: Response): Promise<Response> {
    const matricula: iColaboradorInfo = req.body;
    const matriculaArray = Array.isArray(matricula) ? matricula : [matricula];

    let connection;
    try {
      connection = await MySqlConnection.getConnection();
    } catch (error) {
      const retornar = ErroGeneral.getErrorGeneral(
        'Erro ao abrir conexão com o MySQL',
        error,
      );
      return resp.status(400).json(retornar);
    }

    const cadColaboradores = new CadColaboradorDB();
    const cadAutorizados = new CadAutorizadosDB();
    try {
      const colaboradores: iColaboradorInfo[] = [];
      for (const itemId of matriculaArray) {
        const colaborador = await cadColaboradores.findAtivaDesativa(itemId, connection);
        colaboradores.push(colaborador);
      }

      if (typeof colaboradores === 'undefined') {
        return resp
          .status(400)
          .json(retornoPadrao(1, 'Colaborador não encontrado'));
      }

      const desativarColaborador = colaboradores.map(colaborador => {
        if (colaborador.desativado_em === null) {
          colaborador.desativado_em = new Date();
        } else {
          colaborador.desativado_em = null;
        }

        if (colaborador.desc_situacao === 'Ativo') {
          colaborador.desc_situacao = 'Desativado';
          const situacao = 0;
          cadAutorizados.ativaDesativa(situacao, colaborador.matricula, connection);
        } else {
          colaborador.desc_situacao = 'Ativo';
          const situacao = 1;
          cadAutorizados.ativaDesativa(situacao, colaborador.matricula, connection);
        }

        return colaborador;
      });



      const desativar = desativarColaborador.map(colaborador =>
        cadColaboradores.patch(colaborador, connection),
      );

      await Promise.all(desativar);
      await connection.commit();
      return resp.json(colaboradores);
    } catch (error) {
      await connection.rollback();
      const resultErro = ErroGeneral.getErrorGeneral(
        `Erro ao atualizar a restrição`,
        error,
      );
      return resp.status(400).json(resultErro);
    } finally {
      MySqlConnection.closeConnection(connection);
    }
  }
}
