/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable camelcase */
/* eslint-disable prefer-promise-reject-errors */
/* eslint-disable no-unused-vars */
/* eslint-disable eqeqeq */
/* eslint-disable dot-notation */
/* eslint-disable no-async-promise-executor */
/* eslint-disable prettier/prettier */
import { Connection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import ShortUniqueId from 'short-unique-id';
import { ReturnDefault } from '../Interfaces';
import CadMovimentacao, {
  CadMovimentacaoOut,
  FiltroMovimentacao,
  MovimentacaoInterface
} from '../model/Cad_Movimentacao';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import convertLowerCase from '../utils/convertLowerCase';
import { convertDate2String } from '../utils/dateNow';
import retornoPadrao from '../utils/retornoPadrao';


export default class CadMovimentacaoDB extends CadMovimentacao {
  private rowsUndefined(): Error {
    consoleLog(`Erro ao buscar movimentação, rows = undefined`, pVerbose.erro);
    return new Error(`Erro ao buscar movimentação, rows = undefined`);
  }

  async insert(
    obj: MovimentacaoInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const { randomUUID } = new ShortUniqueId({
      dictionary: 'hex',
      length: 36,
    });
    const sql = `INSERT INTO app_entrega_movimentacao
                 (id, operador_id, colaborador_matricula, produto_id, data_retirada, leitura_qrcode, qtde_retirada)
                 VALUES(?,?,?,?,?,?,?)`;
    const values = [
      obj.id = randomUUID(),
      obj.operador_id,
      obj.colaborador_matricula,
      obj.produto_id,
      obj.data_retirada,
      obj.leitura_qrcode,
      obj.qtde_retirada,
    ];

    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 1) {
        return Promise.resolve(
          retornoPadrao(0, `Movimentação inserida com sucesso!`),
        );
      } else {
        consoleLog(`Erro ao inserir movimentação`, pVerbose.erro);
        return Promise.resolve(retornoPadrao(1, `Erro ao inserir movimentação`));
      }
    } catch (error) {
      consoleLog(`Erro ao inserir movimentação: ${error}`, pVerbose.erro);
      return Promise.reject(error);
    }
  }

  async show(conn: Connection): Promise<CadMovimentacaoOut[]> {
    const sql = `SELECT mov.id,
                 mov.operador_id,
                 op.nome AS operador,
                 mov.colaborador_matricula,
                 col.nome_funcio,
                 mov.produto_id,
                 prod.descricao,
                 mov.desativado_em,
                 mov.motivo,
                 mov.data_retirada,
                 mov.qtde_retirada
                 FROM app_entrega_movimentacao mov
                 INNER JOIN app_entrega_operador op ON op.id = mov.operador_id
                 INNER JOIN app_entrega_colaboradores col ON col.matricula = mov.colaborador_matricula
                 INNER JOIN app_entrega_produto prod ON prod.id = mov.produto_id`;

     try {
      const [rows] = await conn.query<RowDataPacket[]>(sql);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      const autorizados = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
          data_retirada: convertDate2String(new Date(formatObject.data_retirada)),
          desativado_em: formatObject.desativado_em !== null
            ? convertDate2String(new Date(formatObject.desativado_em))
            : null,
        } as CadMovimentacaoOut;
      });
      return Promise.resolve(autorizados);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async filtroMovimentacao(
    filtro: FiltroMovimentacao,
    conn: Connection,
  ): Promise<CadMovimentacaoOut[] | ReturnDefault> {
    let whereCond = '';
    const bindWhere: any = {};

    if (filtro.colaborador_matricula) {
      whereCond += ` AND mov.colaborador_matricula = ?`;
      bindWhere.colaborador_matricula = filtro.colaborador_matricula;
    }
    if (filtro.produto_id) {
      whereCond += ` AND mov.produto_id = ?`;
      bindWhere.produto_id = filtro.produto_id;
    }
    if (filtro.data_retirada_ini && filtro.data_retirada_fim) {
      whereCond += ` AND TRUNC(mov.data_retirada) >= TO_DATE(?, 'DD/MM/YYYY')
                     AND TRUNC(mov.data_retirada) <= TO_DATE(?, 'DD/MM/YYYY')
                     AND mov.desativado_em IS NULL`;
      bindWhere.data_retirada_ini = convertDate2String(
        new Date(filtro.data_retirada_ini),
      );
      bindWhere.data_retirada_fim = convertDate2String(
        new Date(filtro.data_retirada_fim),
      );
    }
    if (filtro.desativado_em_ini && filtro.desativado_em_fim) {
      whereCond += ` AND TRUNC(mov.desativado_em) >= TO_DATE(?, 'DD/MM/YYYY')
                     AND TRUNC(mov.desativado_em) <= TO_DATE(?, 'DD/MM/YYYY')`;
      bindWhere.desativado_em_ini = convertDate2String(
        new Date(filtro.desativado_em_ini),
      );
      bindWhere.desativado_em_fim = convertDate2String(
        new Date(filtro.desativado_em_fim),
      );
    }

    // Remova o 'AND' no início da cláusula WHERE
    whereCond = whereCond.trim().substring(3);

    let sql = `SELECT mov.id,
                mov.operador_id,
                op.nome,
                mov.colaborador_matricula,
                col.nome_funcio,
                mov.produto_id,
                prod.descricao,
                TO_CHAR(mov.desativado_em, 'DD/MM/YYYY HH24:MI:SS') AS desativado_em,
                mov.motivo,
                TO_CHAR(mov.data_retirada, 'DD/MM/YYYY HH24:MI:SS') AS data_retirada,
                mov.qtde_retirada
              FROM app_entrega_movimentacao mov
              INNER JOIN app_entrega_operador op ON op.id = mov.operador_id
              INNER JOIN app_entrega_colaboradores col ON col.matricula = mov.colaborador_matricula
              INNER JOIN app_entrega_produto prod ON prod.id = mov.produto_id`;

    if (whereCond.length > 0) {
      sql += ` WHERE ${whereCond}`;
    }

    sql += ` GROUP BY mov.id, mov.operador_id, op.nome, mov.colaborador_matricula,
            col.nome_funcio, mov.produto_id, prod.descricao, mov.desativado_em,
            mov.motivo, mov.data_retirada, mov.qtde_retirada`;

    try {
      const [rows] = await conn.query<RowDataPacket[]>(sql, bindWhere);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      if (rows.length <= 0) {
        return Promise.resolve(
          retornoPadrao(
            1,
            `Não foram encontradas movimentações com o filtro informado`,
          ),
        );
      }
      const movimentacao = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
        } as CadMovimentacaoOut;
      });
      const movimentacao_lower = convertLowerCase(movimentacao);
      return Promise.resolve(movimentacao_lower);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async ativaDesativa(
    id: string,
    desativado_em: Date,
    motivo: string,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `UPDATE app_entrega_movimentacao SET desativado_em = ?, motivo = ?
                 WHERE id = ?`;
    const values = [
      desativado_em, motivo, id
    ];
    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 0) {
        consoleLog(`Movimentação não encontrada`, pVerbose.erro);
        return Promise.reject(
          retornoPadrao(1, `Movimentação não encontrada`),
        );
      }
      return Promise.resolve(
        retornoPadrao(0, `Movimentação atualizada com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }
}
