/* eslint-disable prettier/prettier */
/* eslint-disable camelcase */
import { Connection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { iColaboradorInfo } from '../model/Cad_Colaborador';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import convertLowerCase from '../utils/convertLowerCase';
import { ReturnDefault } from '../Interfaces';
import retornoPadrao from '../utils/retornoPadrao';

export class CadColaboradorDB {
  private rowsUndefined(): Error {
    consoleLog(
      `Erro ao buscar colaboradores, rows = undefined`,
      pVerbose.erro,
    );
    return new Error(
      `Erro ao buscar colaboradores, rows = undefined`,
    );
  }

  async insert(
    obj: iColaboradorInfo,
    conn: Connection,
  ): Promise<ReturnDefault> {

    const sql = `INSERT INTO app_entrega_colaboradores (matricula, nome_funcio, data_nascto, desc_sexo, internoouexterno, desc_situacao, data_admissao)
                 VALUES (?,?,?,?,?,?, ?)`;
    const values = [
      obj.matricula,
      obj.nome_funcio,
      obj.data_nascto,
      obj.desc_sexo,
      obj.internoouexterno,
      obj.desc_situacao,
      obj.data_admissao,
    ];

      try {
        const [result] = await conn.query<ResultSetHeader>(sql, values);
        if (result.affectedRows === 1) {
          return Promise.resolve(
            retornoPadrao(0, `Colaborador inserido com sucesso!`),
          );
        } else {
          consoleLog(`Erro ao inserir colaborador`, pVerbose.erro);
          return Promise.resolve(retornoPadrao(1, `Erro ao inserir colaborador`));
        }
      } catch (error) {
        consoleLog(`Erro ao inserir colaborador: ${error}`, pVerbose.erro);
        return Promise.reject(error);
      }
  }

  async update(
    obj: iColaboradorInfo,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `UPDATE app_entrega_colaboradores SET nome_funcio = ?, data_nascto = ?, desc_sexo = ? WHERE matricula = ?`;
    const values = [
      obj.nome_funcio,
      obj.data_nascto,
      obj.desc_sexo,
      obj.matricula,
    ];
    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 0) {
        consoleLog(`Autorizado não encontrado`, pVerbose.erro);
        return Promise.reject(
          retornoPadrao(1, `Autorizado não encontrada`),
        );
      }
      return Promise.resolve(
        retornoPadrao(0, `Autorizado atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async getDadosColaborador(
    matricula: number,
    conn: Connection,
  ): Promise<iColaboradorInfo> {
    const sql = `SELECT v.matricula,
                        v.nome_funcio,
                        v.data_admissao,
                        v.situacao,
                        v.desc_situacao,
                        v.data_admissao
                FROM app_entrega_colaboradores v
                WHERE v.matricula = ?`;
    try {
      const [rows] = await conn.query<RowDataPacket[]>(sql, [matricula]);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      const colaboradores: iColaboradorInfo = {
        ...rows[0],
      } as iColaboradorInfo;

      return Promise.resolve(colaboradores);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async showColaborador(conn: Connection): Promise<iColaboradorInfo[]> {
    const sql = `SELECT col.matricula,
                        col.nome_funcio,
                        col.data_nascto,
                        col.desc_sexo,
                        col.internoouexterno,
                        col.desc_situacao,
                        col.data_admissao,
                        col.desativado_em
                        FROM app_entrega_colaboradores col
                        WHERE desc_situacao != 'Demitido'
                        ORDER BY matricula asc`;
     try {
       const [rows] = await conn.query<RowDataPacket[]>(sql);
       if (!Array.isArray(rows)) {
         return Promise.reject(this.rowsUndefined());
       }
       const colaboradores = rows.map((formatObject: RowDataPacket) => {
         return {
           ...formatObject,
         } as iColaboradorInfo;
       });
       return Promise.resolve(colaboradores);
     } catch (error) {
       return Promise.reject(error);
     }
  }

  async buscarToken(
    matricula: number,
    conn: Connection,
  ): Promise<iColaboradorInfo[]> {
    const sql = `SELECT col.matricula,
                 tok.token
                 FROM app_entrega_colaboradores col
                 INNER JOIN entrega_token tok ON tok.matricula = col.matricula AND tok.desativado = 0
                 WHERE col.matricula = ?`;
    try {
      const [rows] = await conn.query<RowDataPacket[]>(sql, [matricula]);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      const colaboradores = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
        } as iColaboradorInfo;
      });
      return Promise.resolve(colaboradores);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async MesAniversarioColaborador(
    matricula: number,
    conn: Connection,
  ): Promise<boolean> {
    const sql = `SELECT v.data_nascto
                FROM app_entrega_colaboradores v
                WHERE v.matricula = ?`;
    try {
      const [result] = await conn.query<RowDataPacket[]>(sql, [matricula]);
      if (!result) {
        return Promise.reject(
          new Error(
            `Dados do colaborador não encontrados, matrícula ${matricula}`,
          ),
        );
      }
      const dados = convertLowerCase(result[0]);
      const mesAniversario = new Date(dados.data_nascto);
      const hoje = new Date();
      // Se for o mês de aniverário do colaborador retorna true;
      if (mesAniversario.getMonth() + 1 === hoje.getMonth() + 1) {
        return Promise.resolve(true);
      }
      return Promise.resolve(false);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async findAtivaDesativa(
    matricula: number,
    conn: Connection,
  ): Promise<iColaboradorInfo> {
    const sql = `SELECT v.matricula,
                        v.desativado_em,
                        v.desc_situacao
                FROM app_entrega_colaboradores v
                WHERE v.matricula = ?`;
    try {
      const [rows] = await conn.query<RowDataPacket[]>(sql, [matricula]);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      const colaboradores: iColaboradorInfo = {
        ...rows[0],
      } as iColaboradorInfo;

      return Promise.resolve(colaboradores);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async patch(
    obj: iColaboradorInfo,
    conn: Connection,
  ): Promise<ReturnDefault> {

    let sql: string;
    let colaboradores_bd;

    if(obj.desc_situacao === 'Ativo' || obj.desc_situacao === 'Desativado'){
      sql = `UPDATE app_entrega_colaboradores SET desativado_em = ?, desc_situacao = ? WHERE matricula = ?`;

      colaboradores_bd = [
        obj.desativado_em,
        obj.desc_situacao,
        obj.matricula,
      ];

    } else {
      sql = `UPDATE app_entrega_colaboradores SET desativado_em = ? WHERE matricula = ?`;

      colaboradores_bd = [
        obj.desativado_em,
        obj.matricula,
      ];
    }



    try {
      const [result] = await conn.execute<ResultSetHeader>(sql, colaboradores_bd);
      if (result.affectedRows === 0) {
        return Promise.reject(this.rowsUndefined());
      }
      return Promise.resolve(
        retornoPadrao(0, `Colaborador atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }
}
