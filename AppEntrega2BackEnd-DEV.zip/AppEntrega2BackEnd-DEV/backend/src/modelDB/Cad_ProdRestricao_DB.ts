/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable prettier/prettier */
/* eslint-disable no-useless-catch */
/* eslint-disable @typescript-eslint/no-unused-vars */
import {
  CadProdRestricao,
  iProdSemRestricao,
  iVerificaPeriodicidade,
  pBolean
} from '../model/Cad_ProdRestricao';
// import { CadColaboradorDB } from './Cad_Colaborador_DB';
import { Connection, RowDataPacket } from 'mysql2/promise';
import convertLowerCase from '../utils/convertLowerCase';
import { convertDateTime2String } from '../utils/dateNow';
import CadComodatoDB from './Cad_Comodato_DB';
import { CadColaboradorDB } from './Cad_Colaborador_DB';
import { dateDiffInDays } from '../utils/dateDiffdays';

interface iColaboradorInfo {
  matricula: number;
  nome_funcio: string;
  data_admissao: string;
  data_nascto: string;
  situacao: string;
  desc_situacao: string;
}

export class CadProdRestricaoDB implements CadProdRestricao {
  async getProdutosSemRestricao(
    matricula: number,
    conn: Connection,
  ): Promise<iProdSemRestricao[] | undefined> {
    const sql = `
    SELECT
      prod.id,
      prod.descricao,
      prod.entrega_com_restricao_comodato,
      prod.retira_com_menos_trinta_dias,
      prod.periodicidade_id,
      peri.descricao AS desc_periodicidade,
      peri.qtd_dias_periodo,
      0 AS existe_pendencia_comodato,
      max.qtd_max_retirada,
      prod.entrega_somente_aniversario
    FROM
      app_entrega_produto prod
      INNER JOIN app_entrega_periodicidade peri ON prod.periodicidade_id = peri.id
      INNER JOIN app_entrega_max_retirada max ON max.produto_id = prod.id
    WHERE
      prod.desativado_em IS NULL
      AND prod.id NOT IN (
        SELECT produto_id FROM app_entrega_restricoes rest
        WHERE rest.matricula = ?
          AND rest.desativado_em IS NULL
      )
      AND max.matricula = ?
      AND max.periodo_liberado_retirada_ini <= CURRENT_DATE()
      AND max.periodo_liberado_retirada_fim >= CURRENT_DATE()
  `;

    try {
      const [rows] = await conn.execute<RowDataPacket[]>(sql, [
        matricula,
        matricula,
      ]);

      if (rows.length <= 0) {
        return Promise.resolve([]);
      }

      const produtosSemRestricao = rows.map((row: any) => {
        const produto: iProdSemRestricao = {
          id: row.id,
          descricao: row.descricao,
          entrega_com_restricao_comodato: row.entrega_com_restricao_comodato,
          retira_com_menos_trinta_dias: row.retira_com_menos_trinta_dias,
          periodicidade_id: row.periodicidade_id,
          desc_periodicidade: row.desc_periodicidade,
          qtd_dias_periodo: row.qtd_dias_periodo,
          existe_pendencia_comodato: row.existe_pendencia_comodato,
          qtd_max_retirada: row.qtd_max_retirada,
          entrega_somente_aniversario: row.entrega_somente_aniversario,
        };

        return produto;
      });

      return Promise.resolve(produtosSemRestricao);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async ProdTrintaDias(
    produtos: iProdSemRestricao[],
    matricula: number,
    conn: Connection,
  ): Promise<iProdSemRestricao[]> {
    // Primeiro verifica se algum item exige que só pode ser entregue se o colaborador entrou a mais de 30 dias.
    const naoEntregaMenosTrintaDias = produtos.filter(
      (prod) => prod.retira_com_menos_trinta_dias === pBolean.nao,
    );
    if (naoEntregaMenosTrintaDias.length <= 0) {
      // Todos os itens podem ser entregue mesmo que o colaborador tenha entrado a menos de 30 dias.
      return Promise.resolve(produtos);
    }
    // Se encontrou produtos que não podem ser entregues verifica a data que o colaborador entrou
    try {
      const colaboradorDB = new CadColaboradorDB();

      const colaboradorInfo = await colaboradorDB.getDadosColaborador(matricula, conn);

      const diasTrabalhando = dateDiffInDays(
        new Date(colaboradorInfo.data_admissao),
        new Date(),
      );
      if (diasTrabalhando >= 30) {
        // Se for mais de 30 dias pode deixar ele retirar tudo;
        return Promise.resolve(produtos);
      }
      // Se for menos de 30 dias, libera somente os produtos sem restrição;
      const podeEntregarMenosTrintaDias = produtos.filter((prod) => {
        if (
          naoEntregaMenosTrintaDias.find((restrito) => restrito.id === prod.id)
        ) {
          // Se o produto tiver na lista de restrito então não leva;
          return false;
        }
        return true;
      });
      return Promise.resolve(podeEntregarMenosTrintaDias);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async ProdPendComodato(
    produtos: iProdSemRestricao[],
    matricula: number,
    conn: Connection,
  ): Promise<iProdSemRestricao[]> {
    const naoEntregaPendComodato = produtos.filter(
      (prod) => prod.entrega_com_restricao_comodato === pBolean.nao,
    );
    // Se nenhum item for pendente de comodato então nem precisa verificar se ele tem pendência;
    if (naoEntregaPendComodato.length <= 0) return Promise.resolve(produtos);
    const cadComodatoDB = new CadComodatoDB({});
    try {
      // Busca a quantidade de todos os comodatos que o colaborador retirou desde quando entrou na empresa agrupando por produto;
      const totalRetirados = await cadComodatoDB.getTotalComodatoRetirado(
        conn,
        matricula,
      );
      if (totalRetirados.length <= 0) {
        // Se ele não retirou nenhum comodato até hoje marca os itens que ele não esta devendo nada;
        const nprod = produtos.map((prod) => {
          prod.existe_pendencia_comodato = pBolean.nao;
          return prod;
        });
        return Promise.resolve(nprod);
      }
      // Busca a quantidade de todos os comodatos que o colaborador DEVOLVEU agrupando por produto;
      const totalDevolvidos = await cadComodatoDB.getTotalComodatoDevolvido(
        conn,
        matricula,
      );
      // Verifica se falta entregar algum comodato;
      const temPendencia = totalRetirados.some((retirados) => {
        const devolvido = totalDevolvidos.find(
          (dev) => dev.produto_id === retirados.produto_id,
        );
        if (!devolvido) {
          // Se não foi devolvido nenhuma unidade desse produto então já retorna true para mostrar que ele tem pendência;
          return true;
        }
        if (devolvido.qtd_total_devolvida < retirados.qtd_total_retirada) {
          // Se a quantidade devolvida for menor que a quantidade retirada desse produto então retorna true para mostrar que ele tem pendência;
          return true;
        }
        return false;
      });

      if (temPendencia) {
        // Se o colaborador estiver devendo devolver algum comodato marca todos os itens que existe essa pedência;
        const prodsPendencia = produtos.map((prod) => {
          prod.existe_pendencia_comodato = pBolean.sim;
          return prod;
        });
        return Promise.resolve(prodsPendencia);
      }
      // Se não estiver devendo comodato marca os itens avisando que não tem pendência
      const prodsSemPendencia = produtos.map((prod) => {
        prod.existe_pendencia_comodato = pBolean.nao;
        return prod;
      });
      return Promise.resolve(prodsSemPendencia);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async VerificaSeJaRetirouNaPeriodicidade(
    matricula: number,
    produto: iProdSemRestricao,
    conn: Connection,
  ): Promise<iVerificaPeriodicidade> {
    // Pega a data atual menos quantidade de dias do período para descobrir até quando temos que procurar se o colaborador já retirou esse produto.
    const dataInicioPeriodo = new Date();
    dataInicioPeriodo.setDate(dataInicioPeriodo.getDate() - produto.qtd_dias_periodo);

    const sql = `
      SELECT
        mov.colaborador_matricula,
        mov.produto_id,
        SUM(mov.qtde_retirada) as total_retirado
      FROM
        app_entrega_movimentacao mov
      WHERE
        mov.data_retirada >= ?
        AND mov.colaborador_matricula = ?
        AND mov.produto_id = ?
        AND mov.desativado_em IS NULL
      GROUP BY
        mov.colaborador_matricula, mov.produto_id
    `;

    const dtNew = convertDateTime2String(dataInicioPeriodo);
    const binds = [
      dtNew.split(' ')[0], // data_inicio_periodo
      matricula,           // matricula
      produto.id,           // produto_id
    ];

    try {
      // Procura na tabela app_entrega_movimentacao se o colaborador retirou esse produto dentro do prazo estipulado como periodicidade do mesmo.
      const [rows] = await conn.execute<RowDataPacket[]>(sql, binds);

      if (!rows || rows.length === 0) {
        // Se não encontrou nada, marca que pode retirar esse produto.
        return Promise.resolve({
          id_produto: produto.id,
          pode_retirar: true,
          qtd_ja_retirada: 0,
        });
      }

      const produtosRetirados = convertLowerCase(rows[0]);

      if (produtosRetirados.total_retirado >= produto.qtd_max_retirada) {
        // Já retirou todas as unidades permitidas desse produto, não deixa retirar mais nada.
        return Promise.resolve({
          id_produto: produto.id,
          pode_retirar: false,
          qtd_ja_retirada: produtosRetirados.total_retirado,
        });
      }

      // Caso ainda não tenha retirado tudo, deixa retirar.
      return Promise.resolve({
        id_produto: produto.id,
        pode_retirar: true,
        qtd_ja_retirada: produtosRetirados.total_retirado,
      });
    } catch (error) {
      return Promise.reject(error);
    }
  }
}
