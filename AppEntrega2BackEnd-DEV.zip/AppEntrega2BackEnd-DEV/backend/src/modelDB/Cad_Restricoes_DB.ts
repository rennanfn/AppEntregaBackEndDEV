/* eslint-disable camelcase */
/* eslint-disable no-async-promise-executor */
/* eslint-disable prettier/prettier */
import { Connection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { ReturnDefault } from '../Interfaces';
import CadRestricoes, {
  CadRestricoesOut,
  RestricoesInterface,
} from '../model/Cad_Restricoes';
import convertLowerCase from '../utils/convertLowerCase';
import { convertDate2String } from '../utils/dateNow';
import retornoPadrao from '../utils/retornoPadrao';
import { consoleLog, pVerbose } from '../utils/consoleLog';


export default class CadRestricoesDB extends CadRestricoes {
  private rowsUndefined(): Error {
    consoleLog(`Erro ao buscar restrições, rows = undefined`, pVerbose.erro);
    return new Error(`Erro ao buscar restrições, rows = undefined`);
  }

  async insert(
    obj: RestricoesInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {

    const sql = `INSERT INTO app_entrega_restricoes (id, matricula, produto_id, motivo, desativado_em) VALUES (?, ?, ?, ?, ?)`;

    const restricoes_bd = [
      obj.id,
      obj.matricula,
      obj.produto_id,
      obj.motivo,
      obj.desativado_em,
    ];

    return new Promise(async (resolve, reject) => {
      try {
        const [result] = await conn.query<ResultSetHeader>(sql, restricoes_bd);
        if (result.affectedRows === 0) {
          consoleLog(
            `Erro ao inserir restrições, rows = undefined`,
            pVerbose.erro,
          );
          return reject(
            retornoPadrao(1, `Erro ao inserir restrições, rows = undefined`),
          );
        }
        return resolve(retornoPadrao(0, `Restrição inserida com sucesso!`));
      } catch (error) {
        return reject(error);
      }
    });
  }

  async update(
    obj: RestricoesInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `UPDATE app_entrega_restricoes SET matricula = ?, produto_id = ?, motivo = ? WHERE id = ?`;

    const restricoes_bd = [
      obj.matricula,
      obj.produto_id,
      obj.motivo,
      obj.id,
    ];
    try {
      const [result] = await conn.execute<ResultSetHeader>(sql, restricoes_bd);

      if (result.affectedRows === 0) {
        return Promise.reject(this.rowsUndefined());
      }

      return Promise.resolve(
        retornoPadrao(0, `Restrição atualizada com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async show(conn: Connection): Promise<CadRestricoesOut[]> {
    const sql = `SELECT rest.id,
                 rest.matricula,
                 rest.produto_id,
                 prod.descricao,
                 rest.motivo,
                 rest.desativado_em
                 FROM app_entrega_restricoes rest
                 LEFT JOIN app_entrega_produto prod on prod.id = rest.produto_id ORDER BY rest.id asc`;

    const [result] = await conn.execute<RowDataPacket[]>(sql);
    const restricoes = result;

    if (typeof restricoes === 'undefined') {
      return Promise.reject(this.rowsUndefined());
    }
    const restricoes_lower = convertLowerCase(restricoes);
    const cadRestricoes = restricoes_lower.map(restricoes => {
      const item_restricoes = restricoes;

      if (restricoes.desativado_em != null) {
        item_restricoes.desativado_em = convertDate2String(
          new Date(restricoes.desativado_em),
        );
      }
      return item_restricoes as CadRestricoesOut;
    });
    return Promise.resolve(cadRestricoes);
  }

  async patch(
    obj: RestricoesInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `UPDATE app_entrega_restricoes SET desativado_em = ? WHERE id = ?`;

    const restricoes_bd = [
      obj.desativado_em,
      obj.id,
    ];

    try {
      const [result] = await conn.execute<ResultSetHeader>(sql, restricoes_bd);
      if (result.affectedRows === 0) {
        return Promise.reject(this.rowsUndefined());
      }
      return Promise.resolve(
        retornoPadrao(0, `Restrição atualizada com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async find(
    id: string,
    conn: Connection,
  ): Promise<CadRestricoesOut[]> {
    const sql = `SELECT rest.id,
                 rest.matricula,
                 rest.produto_id,
                 prod.descricao,
                 rest.motivo,
                 rest.desativado_em
                 FROM app_entrega_restricoes rest
                 LEFT JOIN app_entrega_produto prod on prod.id = rest.produto_id
                 WHERE rest.id = ? ORDER BY rest.id asc`;

    const [result] = await conn.execute<RowDataPacket[]>(sql, [id]);
    const restricoes = result;

    if (typeof restricoes === 'undefined') {
      return Promise.reject(this.rowsUndefined());
    }
    const restricoes_lower = convertLowerCase(restricoes);
    const cadRestricoes = restricoes_lower.map(restricoes => {
      const item_restricoes = restricoes;

      item_restricoes.desativado_em = convertDate2String(
        new Date(restricoes.desativado_em),
      );
      return item_restricoes as CadRestricoesOut;
    });
    return Promise.resolve(cadRestricoes);
  }

  async findPatch(
    id: string,
    conn: Connection,
  ): Promise<RestricoesInterface[]> {
    return new Promise(async (resolve, reject) => {
      const sql = `SELECT id, desativado_em FROM app_entrega_restricoes WHERE id = ?`;

      try {
        const result = await conn.execute<RowDataPacket[]>(sql, [id]);

        const restricoes = result[0] as RestricoesInterface[];
        if (typeof restricoes === 'undefined') {
          consoleLog(
            `Erro ao buscar restricoes, rows = undefined`,
            pVerbose.erro,
          );
          return reject(
            retornoPadrao(1, `Erro ao buscar restricoes, rows = undefined`),
          );
        }
        return resolve(convertLowerCase(restricoes));
      } catch (error) {
        return reject(error);
      }
    });
  }
}
