/* eslint-disable object-shorthand */
/* eslint-disable camelcase */
/* eslint-disable no-async-promise-executor */
/* eslint-disable prettier/prettier */
/* eslint-disable prettier/prettier */
import { Connection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { ReturnDefault } from '../Interfaces';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import { convertDate2String } from '../utils/dateNow';
import retornoPadrao from '../utils/retornoPadrao';
import CadMaxRetirada, {
  CadMaxRetiradaOut,
  MaxRetiradaInterface
} from './../model/Cad_Max_Retirada';

export default class CadMaxRetiradaDB extends CadMaxRetirada {
  private rowsUndefined(): Error {
    consoleLog(`Erro ao buscar produto, rows = undefined`, pVerbose.erro);
    return new Error(`Erro ao buscar produto, rows = undefined`);
  }

  async insert(
    obj: MaxRetiradaInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `INSERT INTO
                 app_entrega_max_retirada(matricula, produto_id, criado_em, qtd_max_retirada, periodo_liberado_retirada_ini, periodo_liberado_retirada_fim)
                 VALUES (?,?,?,?,?,?)`;
    const values = [
      obj.matricula,
      obj.produto_id,
      obj.criado_em,
      obj.qtd_max_retirada,
      obj.periodo_liberado_retirada_ini,
      obj.periodo_liberado_retirada_fim,
    ];
    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 1) {
        return Promise.resolve(
          retornoPadrao(0, `Permissões de retirada inseridas com sucesso!`),
        );
      } else {
        consoleLog(`Erro ao inserir permissões de retirada`, pVerbose.erro);
        return Promise.resolve(retornoPadrao(1, `Erro ao inserir permissões de retirada`));
      }
    } catch (error) {
      consoleLog(`Erro ao inserir permissões de retirada: ${error}`, pVerbose.erro);
      return Promise.reject(error);
    }
  }

  async update(
    obj: MaxRetiradaInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {

    const dataAtual = obj.criado_em as string;

    const partesData = dataAtual.split("/");
    const dia = partesData[0];
    const mes = partesData[1];
    const ano = partesData[2];

    const dataConvertida = `${ano}-${mes.padStart(2, "0")}-${dia.padStart(2, "0")}`;

    const sql = `UPDATE app_entrega_max_retirada
                 SET qtd_max_retirada = ?,
                 periodo_liberado_retirada_ini = ?,
                 periodo_liberado_retirada_fim = ?
                 WHERE matricula = ?
                 AND produto_id = ?
                 AND criado_em = ?`;
    const values = [
      obj.qtd_max_retirada,
      obj.periodo_liberado_retirada_ini,
      obj.periodo_liberado_retirada_fim,
      obj.matricula,
      obj.produto_id,
      dataConvertida,
    ];
    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 0) {
        consoleLog(`Permissões de retirada não encontradas`, pVerbose.erro);
        return Promise.reject(
          retornoPadrao(1, `Permissões de retirada não encontradas`),
        );
      }
      return Promise.resolve(
        retornoPadrao(0, `Permissões de retirada atualizadas com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async show(conn: Connection): Promise<CadMaxRetiradaOut[]> {
    const sql = `SELECT max.matricula,
                 col.nome_funcio,
                 max.produto_id,
                 prod.descricao,
                 max.criado_em,
                 max.qtd_max_retirada,
                 max.periodo_liberado_retirada_ini,
                 max.periodo_liberado_retirada_fim
                 FROM app_entrega_max_retirada max
                 LEFT JOIN app_entrega_colaboradores col on col.matricula = max.matricula
                 LEFT JOIN app_entrega_produto prod on prod.id = max.produto_id ORDER BY max.periodo_liberado_retirada_ini desc, col.nome_funcio asc`;

     try {
      const [rows] = await conn.query<RowDataPacket[]>(sql);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      const max_retirada = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
          criado_em: convertDate2String(new Date(formatObject.criado_em)),
          periodo_liberado_retirada_ini: convertDate2String(new Date(formatObject.periodo_liberado_retirada_ini)),
          periodo_liberado_retirada_fim: convertDate2String(new Date(formatObject.periodo_liberado_retirada_fim)),
        } as CadMaxRetiradaOut;
      });
      return Promise.resolve(max_retirada);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async find(
    matricula: number,
    conn: Connection,
  ): Promise<CadMaxRetiradaOut[]> {
    // const sql = `SELECT * FROM app_entrega_max_retirada WHERE matricula = :matricula ORDER BY matricula asc`;
    const sql = `SELECT max.matricula,
                col.nome_funcio,
                max.produto_id,
                prod.descricao,
                to_char(max.criado_em, 'YYYY-MM-DD HH24:MI:SS') AS criado_em,
                max.qtd_max_retirada,
                max.periodo_liberado_retirada_ini,
                max.periodo_liberado_retirada_fim,
                FROM app_entrega_max_retirada max
                LEFT JOIN app_entrega_colaboradores col ON col.matricula = max.matricula
                LEFT JOIN app_entrega_produto prod ON prod.id = max.produto_id
                WHERE max.matricula = ?
                AND NOT EXISTS (
                  SELECT 1
                  FROM app_entrega_movimentacao mov
                  WHERE mov.colaborador_matricula = max.matricula
                  AND mov.produto_id = max.produto_id
                )
                ORDER BY max.criado_em desc`;

    try {
      const [rows] = await conn.query<RowDataPacket[]>(sql, [matricula]);
      if (typeof rows === 'undefined') {
        return Promise.reject(this.rowsUndefined());
      }
      const max_retirada = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
          periodo_liberado_retirada_ini: convertDate2String(new Date(formatObject.periodo_liberado_retirada_ini)),
          periodo_liberado_retirada_fim: convertDate2String(new Date(formatObject.periodo_liberado_retirada_fim)),
        } as CadMaxRetiradaOut;
      });
      return Promise.resolve(max_retirada);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async verificaMaxRetirada(
    obj: MaxRetiradaInterface,
    conn: Connection,
  ): Promise<CadMaxRetiradaOut[]> {
    const sql = `SELECT ret.produto_id,
                      ret.criado_em,
                      ret.qtd_max_retirada,
                      ret.matricula,
                      ret.periodo_liberado_retirada_ini,
                      ret.periodo_liberado_retirada_fim,
                      prod.descricao as prod_descricao
                  FROM app_entrega_max_retirada ret
                  inner JOIN app_entrega_produto prod on prod.id = ret.produto_id
                  WHERE ret.matricula = ?
                  AND ret.produto_id = ?
                  AND
                  ( ( ret.periodo_liberado_retirada_ini <= STR_TO_DATE( ?,'%Y-%m-%d')
                      and ret.periodo_liberado_retirada_fim >= STR_TO_DATE( ?,'%Y-%m-%d')
                    )
                    OR
                    (
                      ret.periodo_liberado_retirada_ini <= STR_TO_DATE( ?,'%Y-%m-%d')
                      and ret.periodo_liberado_retirada_fim >= STR_TO_DATE( ?,'%Y-%m-%d')
                    )
                  )`;
    const values = [
      obj.matricula,
      obj.produto_id,
      obj.periodo_liberado_retirada_ini,
      obj.periodo_liberado_retirada_fim,
      obj.periodo_liberado_retirada_ini,
      obj.periodo_liberado_retirada_fim,
    ];

    try {
      const [rows] = await conn.query<RowDataPacket[]>(sql, values);
      if (typeof rows === 'undefined') {
        return Promise.reject(this.rowsUndefined());
      }
      const max_retirada = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
        } as CadMaxRetiradaOut;
      });
      return Promise.resolve(max_retirada);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async delete(
    obj: MaxRetiradaInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const dataAtual = obj.criado_em as string;

    const partesData = dataAtual.split("/");
    const dia = partesData[0];
    const mes = partesData[1];
    const ano = partesData[2];

    const dataConvertida = `${ano}-${mes.padStart(2, "0")}-${dia.padStart(2, "0")}`;

    const sql = `DELETE FROM app_entrega_max_retirada WHERE matricula = ? AND produto_id = ? AND criado_em = ?`;
    const values = [
      obj.matricula,
      obj.produto_id,
      dataConvertida,
    ];
      try {
        const result = await conn.query<ResultSetHeader>(sql, values);
        if (!result) {
          consoleLog(
            `Erro ao deletar permissões de retirada`,
            pVerbose.erro,
          );
          return Promise.reject(
            retornoPadrao(1, `Erro ao deletar permissões de retirada`),
          );

        } else {
          return Promise.resolve(retornoPadrao(0, `Permissões de retirada deletadas com sucesso!`));
        }
      } catch (error) {
        return Promise.reject(error);
      }
  }
}
