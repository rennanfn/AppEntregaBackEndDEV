/* eslint-disable @typescript-eslint/no-non-null-assertion */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable no-undef */
/* eslint-disable camelcase */
/* eslint-disable no-async-promise-executor */
/* eslint-disable prettier/prettier */
/* eslint-disable no-import-assign */
import { Connection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { ReturnDefault } from '../Interfaces';
import convertLowerCase from '../utils/convertLowerCase';
import { convertDate2String } from '../utils/dateNow';
import retornoPadrao from '../utils/retornoPadrao';
import CadProduto, {
  CadProdutoOut,
  ProdutoInterface,
} from './../model/Cad_Produto';
import { consoleLog, pVerbose } from '../utils/consoleLog';

export default class CadProdutoDB extends CadProduto {
  private rowsUndefined(): Error {
    consoleLog(`Erro ao buscar produto, rows = undefined`, pVerbose.erro);
    return new Error(`Erro ao buscar produto, rows = undefined`);
  }

  async insert(
    obj: ProdutoInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {

    const sql = `INSERT INTO app_entrega_produto (id, descricao, entrega_com_restricao_comodato, retira_com_menos_trinta_dias, entrega_somente_aniversario,
      periodicidade_id, criado_em, desativado_em) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

    const values = [
      obj.id,
      obj.descricao,
      obj.entrega_com_restricao_comodato,
      obj.retira_com_menos_trinta_dias,
      obj.entrega_somente_aniversario,
      obj.periodicidade_id,
      obj.criado_em,
      obj.desativado_em,
    ];

    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);

      if (result.affectedRows === 0) {
        consoleLog(
          `Erro ao inserir produto, rows = undefined`,
          pVerbose.erro,
        );
        return Promise.reject(
          retornoPadrao(1, `Erro ao inserir produto, rows = undefined`),
        );
      }

      // Verifica se o produto é comodato: 0 = Não e 1 = Sim. Caso seja, insere o id do produto na tabela APP_ENTREGA_COMODATO
       // Verifica se o produto é comodato: 0 = Não e 1 = Sim. Caso seja, insere o id do produto na tabela APP_ENTREGA_COMODATO
        if (obj.comodato === 1) {
          const sqlComodato ='INSERT INTO app_entrega_comodato (produto_id) VALUES (?)';
          const [resultComodato] = await conn.query<ResultSetHeader>(sqlComodato,[obj.id]);
          if (resultComodato.affectedRows === 0) {
            consoleLog(
              `Erro ao inserir comodato, rows = undefined`,
              pVerbose.erro,
            );
            return Promise.reject(
              retornoPadrao(1, `Erro ao inserir comodato, rows = undefined`),
            );
          }
        }

      return Promise.resolve(retornoPadrao(0, `Produto inserido com sucesso!`));
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async update(
    obj: ProdutoInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {

    const sql = `UPDATE app_entrega_produto SET descricao = ?, entrega_com_restricao_comodato = ?, retira_com_menos_trinta_dias = ?,
    entrega_somente_aniversario = ?, periodicidade_id = ? WHERE id = ?`;

    const values = [
      obj.descricao,
      obj.entrega_com_restricao_comodato,
      obj.retira_com_menos_trinta_dias,
      obj.entrega_somente_aniversario,
      obj.periodicidade_id,
      obj.id,
    ];


    try {
      const [result] = await conn.execute<ResultSetHeader>(sql, values);

      if (obj.comodato === 1) {
        const sqlComodato =
          'INSERT INTO app_entrega_comodato (produto_id) VALUES (?)';
        await conn.execute(sqlComodato, [obj.id]);
      }

      if (obj.comodato === 0) {
        const sqlDesativarComodato =
          'UPDATE app_entrega_comodato SET desativado_em = CURRENT_DATE WHERE produto_id = ? AND desativado_em IS NULL';
        await conn.execute(sqlDesativarComodato, [obj.id]);
      }

      if (obj.comodato === undefined) {
        const sqlAtivarComodato =
          'UPDATE app_entrega_comodato SET desativado_em = NULL WHERE produto_id = ?';
        await conn.execute(sqlAtivarComodato, [obj.id]);
      }

      if (result.affectedRows === 0) {
        consoleLog(`Não encontrado produto}`, pVerbose.erro);
        return Promise.resolve(
          retornoPadrao(1, `Não encontrado produto ${obj.descricao}`),
        );
      }

      return Promise.resolve(
        retornoPadrao(0, `Produto atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async verificaComodato(
    produto_id: string,
    conn: Connection,
  ): Promise<CadProdutoOut[]> {

    const sql = 'SELECT * FROM app_entrega_comodato WHERE produto_id = ?';
    try {
      const [result] = await conn.execute<RowDataPacket[]>(sql, [produto_id]);

      if (!result) {
        return Promise.reject(this.rowsUndefined());
      }

      const res_comodato: CadProdutoOut[] = result.map(row => ({
        produto_id: row.produto_id,
        criado_em: row.criado_em,
        desativado_em: row.desativado_em,
        // Adicione outros campos necessários aqui
      }));

      return Promise.resolve(res_comodato);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async patch(
    obj: ProdutoInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {

    const sql = `UPDATE app_entrega_produto SET desativado_em = ? WHERE id = ?`;

    const values = [
      obj.desativado_em,
      obj.id,
    ]

    try {
      const [result] = await conn.execute<ResultSetHeader>(sql, values);

      if (result.affectedRows <= 0) {
        return Promise.reject(this.rowsUndefined());
      }

      return Promise.resolve(
        retornoPadrao(0, `Produto atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async show(conn: Connection): Promise<CadProdutoOut[]> {
    // const sql = `SELECT * FROM app_entrega_produto ORDER BY id asc`;
    const sql = `SELECT prod.id,
                 prod.descricao,
                 prod.entrega_com_restricao_comodato,
                 prod.retira_com_menos_trinta_dias,
                 prod.periodicidade_id,
                 per.descricao as descricao_periodo,
                 prod.criado_em,
                 prod.desativado_em,
                 prod.entrega_somente_aniversario,
                 SUM(CASE WHEN com.produto_id IS NOT NULL AND com.desativado_em IS NULL THEN 1 ELSE 0 END) AS comodato
                 FROM app_entrega_produto prod
                 LEFT JOIN app_entrega_periodicidade per ON per.id = prod.periodicidade_id
                 LEFT JOIN app_entrega_comodato com ON com.produto_id = prod.id
                 GROUP BY prod.id,
                 prod.descricao,
                 prod.entrega_com_restricao_comodato,
                 prod.retira_com_menos_trinta_dias,
                 prod.periodicidade_id,
                 per.descricao,
                 prod.criado_em,
                 prod.desativado_em,
                 prod.entrega_somente_aniversario
                 ORDER BY prod.descricao ASC`;

     const [result] = await conn.execute<RowDataPacket[]>(sql);

    if (result.length <= 0) {
      consoleLog('Nenhum produto encontrado', pVerbose.erro);
      return Promise.resolve([]);
    }

    const cadProduto: CadProdutoOut[] = result.map(produto => {
      const item_produto = produto;

      item_produto.criado_em = convertDate2String(new Date(produto.criado_em));

      if (produto.desativado_em !== null) {
        item_produto.desativado_em = convertDate2String(
          new Date(produto.desativado_em),
        );
      }
      return item_produto as CadProdutoOut;
    });

    return Promise.resolve(cadProduto);
  }

  async showAtivo(conn: Connection): Promise<CadProdutoOut[]> {
    const sql = `SELECT prod.id,
                 prod.descricao,
                 prod.entrega_com_restricao_comodato,
                 prod.retira_com_menos_trinta_dias,
                 prod.periodicidade_id,
                 per.descricao as descricao_periodo,
                 prod.criado_em,
                 prod.desativado_em,
                 prod.entrega_somente_aniversario,
                 SUM(CASE WHEN com.produto_id IS NOT NULL AND com.desativado_em IS NULL THEN 1 ELSE 0 END) AS comodato
                 FROM app_entrega_produto prod
                 LEFT JOIN app_entrega_periodicidade per ON per.id = prod.periodicidade_id
                 LEFT JOIN app_entrega_comodato com ON com.produto_id = prod.id
                 WHERE prod.desativado_em IS NULL
                 GROUP BY prod.id,
                 prod.descricao,
                 prod.entrega_com_restricao_comodato,
                 prod.retira_com_menos_trinta_dias,
                 prod.periodicidade_id,
                 per.descricao,
                 prod.criado_em,
                 prod.desativado_em,
                 prod.entrega_somente_aniversario
                 ORDER BY prod.descricao ASC`;

    try {
      const [result] = await conn.execute<RowDataPacket[]>(sql);

      if (result.length <= 0) {
        consoleLog('Nenhum produto ativo encontrado', pVerbose.erro);
        return Promise.resolve([]);
      }

      const cadProduto = result.map(produto => {
        const item_produto = produto;

        item_produto.criado_em = convertDate2String(
          new Date(produto.criado_em),
        );

        return item_produto as CadProdutoOut;
      });

      return Promise.resolve(cadProduto);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async find(id: string, conn: Connection): Promise<CadProdutoOut[]> {
    const sql = `SELECT prod.id,
                 prod.descricao,
                 prod.entrega_com_restricao_comodato,
                 prod.retira_com_menos_trinta_dias,
                 prod.periodicidade_id,
                 per.descricao as descricao_periodo,
                 prod.criado_em,
                 prod.desativado_em,
                 prod.entrega_somente_aniversario,
                 SUM(CASE WHEN com.produto_id IS NOT NULL AND com.desativado_em IS NULL THEN 1 ELSE 0 END) AS comodato
                 FROM app_entrega_produto prod
                 LEFT JOIN app_entrega_periodicidade per ON per.id = prod.periodicidade_id
                 LEFT JOIN app_entrega_comodato com ON com.produto_id = prod.id
                 WHERE prod.id = ?
                 GROUP BY prod.id,
                 prod.descricao,
                 prod.entrega_com_restricao_comodato,
                 prod.retira_com_menos_trinta_dias,
                 prod.periodicidade_id,
                 per.descricao,
                 prod.criado_em,
                 prod.desativado_em,
                 prod.entrega_somente_aniversario
                 ORDER BY prod.descricao ASC`;

    try {
      const [result] = await conn.execute<RowDataPacket[]>(sql, [id]);

      if (result.length <= 0) {
        consoleLog(`Produto com ID ${id} não encontrado`, pVerbose.erro);
        return Promise.resolve([]);
      }

      const cadProduto = result.map(produto => {
        const item_produto = produto;

        item_produto.criado_em = convertDate2String(
          new Date(produto.criado_em),
        );

        if (produto.desativado_em !== null) {
          item_produto.desativado_em = convertDate2String(
            new Date(produto.desativado_em),
          );
        }

        return item_produto as CadProdutoOut;
      });

      return Promise.resolve(cadProduto);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async findPatch(
    id: string,
    conn: Connection,
  ): Promise<ProdutoInterface[]> {
    return new Promise(async (resolve, reject) => {
      const sql = `SELECT id, desativado_em FROM app_entrega_produto WHERE id = ?`;

      try {
        const [result] = await conn.execute<RowDataPacket[]>(sql, [id]);
        const produto = result as ProdutoInterface[];
        if (typeof produto === 'undefined') {
          consoleLog(`Erro ao buscar produto, rows = undefined`, pVerbose.erro);
          return reject(
            retornoPadrao(1, `Erro ao buscar produto, rows = undefined`),
          );
        }
        return resolve(convertLowerCase(produto));
      } catch (error) {
        return reject(error);
      }
    });
  }
}
