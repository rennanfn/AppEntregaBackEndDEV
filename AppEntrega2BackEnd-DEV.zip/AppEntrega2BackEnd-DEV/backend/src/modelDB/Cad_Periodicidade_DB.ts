/* eslint-disable camelcase */
/* eslint-disable no-async-promise-executor */
/* eslint-disable prettier/prettier */
/* eslint-disable no-undef */
import { ReturnDefault } from '../Interfaces';
import convertLowerCase from '../utils/convertLowerCase';
import { convertDate2String } from '../utils/dateNow';
import retornoPadrao from '../utils/retornoPadrao';
import CadPeriodicidade, {
  CadPeriodicidadeOut,
  PeriodicidadeInterface,
} from './../model/Cad_Periodicidade';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import { Connection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';

export default class CadPeriodicidadeDB extends CadPeriodicidade {
  private rowsUndefined(): Error {
    consoleLog(`Erro ao buscar período, rows = undefined`, pVerbose.erro);
    return new Error(`Erro ao buscar período, rows = undefined`);
  }

  async insert(
    obj: PeriodicidadeInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {

    const sql = `INSERT INTO app_entrega_periodicidade (id, descricao, qtd_dias_periodo, criado_em, desativado_em) VALUES (?, ?, ?, ?, ?)`;

    const values = [
      obj.id,
      obj.descricao,
      obj.qtd_dias_periodo,
      obj.criado_em,
      obj.desativado_em,
    ];

    const connection = conn;
    try {
      const [result] = await connection.query<ResultSetHeader>(
        sql,
        values,
      );

      if (result.affectedRows === 0) {
        consoleLog(
          `Erro ao inserir período, rows = undefined`,
          pVerbose.erro,
        );
        return Promise.reject(
          retornoPadrao(1, `Erro ao inserir período, rows = undefined`),
        );
      }
      // Se retornou periodicidadeOut é porque inseriu
      return Promise.resolve(retornoPadrao(0, `Período inserido com sucesso!`));
    } catch (error) {
      return Promise.reject(error);
    }

  }

  async update(
    obj: PeriodicidadeInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {

    const sql = `UPDATE app_entrega_periodicidade SET descricao = ?, qtd_dias_periodo = ? WHERE id = ?`;

    const values = [
      obj.descricao,
      obj.qtd_dias_periodo,
      obj.id,
    ]

    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 0) {
        consoleLog(`Período não encontrado`, pVerbose.erro);
        return Promise.resolve(retornoPadrao(1, `Período não encontrado`));
      }

      return Promise.resolve(
        retornoPadrao(0, `Período atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async patch(
    obj: PeriodicidadeInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `UPDATE app_entrega_periodicidade SET desativado_em = ? WHERE id = ?`;

    const values = [
      obj.desativado_em,
      obj.id,
    ]

    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);

      if (result.affectedRows === 0) {
        consoleLog(`Período não encontrado`, pVerbose.erro);
        return Promise.resolve(retornoPadrao(0, `Período não encontrado`));
      }

      return Promise.resolve(
        retornoPadrao(0, `Período atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async show(conn: Connection): Promise<CadPeriodicidadeOut[]> {
    const sql = `SELECT * FROM app_entrega_periodicidade ORDER BY id ASC`;

    try {
      const [rows] = await conn.execute<RowDataPacket[]>(sql);

      if (!rows || rows.length === 0) {
        return Promise.reject(this.rowsUndefined());
      }

      const cadPeriodo = rows.map((periodo: RowDataPacket) => {
        const item_periodo = periodo as CadPeriodicidadeOut;;

        item_periodo.criado_em = convertDate2String(new Date(periodo.criado_em));

        if (periodo.desativado_em !== null) {
          item_periodo.desativado_em = convertDate2String(new Date(periodo.desativado_em));
        }

        return item_periodo;
      });

      return Promise.resolve(cadPeriodo);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async showAtivo(conn: Connection): Promise<CadPeriodicidadeOut[]> {
    const sql = `SELECT * FROM app_entrega_periodicidade WHERE desativado_em IS NULL ORDER BY id asc`;

    try {
      const [rows] = await conn.execute<RowDataPacket[]>(sql);

      if (!rows || rows.length === 0) {
        return Promise.reject(this.rowsUndefined());
      }

      const cadPeriodo = rows.map((periodo: RowDataPacket) => {
        const item_periodo = periodo as CadPeriodicidadeOut;

        item_periodo.criado_em = convertDate2String(new Date(periodo.criado_em));

        return item_periodo;
      });

      return Promise.resolve(cadPeriodo);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async find(
    id: string,
    conn: Connection,
  ): Promise<CadPeriodicidadeOut[]> {
    const sql = `SELECT * FROM app_entrega_periodicidade WHERE id = ?`;

  try {
    const [rows] = await conn.query<RowDataPacket[]>(sql, [id]);

    if (!rows || rows.length === 0) {
      return Promise.reject(this.rowsUndefined());
    }

    const cadPeriodo = rows.map((periodo: RowDataPacket) => {
      const item_periodo = periodo as CadPeriodicidadeOut;

      item_periodo.criado_em = convertDate2String(new Date(periodo.criado_em));

      if (periodo.desativado_em !== null) {
        item_periodo.desativado_em = convertDate2String(
          new Date(periodo.desativado_em),
        );
      }

      return item_periodo;
    });

    return Promise.resolve(cadPeriodo);
  } catch (error) {
    return Promise.reject(error);
  }
  }

  async findPatch(
    id: string,
    conn: Connection,
  ): Promise<PeriodicidadeInterface[]> {
    return new Promise(async (resolve, reject) => {
      const sql = `SELECT id, desativado_em FROM app_entrega_periodicidade WHERE id = ?`;

      try {
        const [result] = await conn.query<RowDataPacket[]>(sql, [id]);

        if (!result || result.length === 0) {
          consoleLog(
            `Erro ao buscar o período, rows = undefined`,
            pVerbose.erro,
          );
          return reject(
            retornoPadrao(1, `Erro ao buscar período, rows = undefined`),
          );
        }

        const periodicidade = result[0] as PeriodicidadeInterface;
        return resolve([convertLowerCase(periodicidade)]);
      } catch (error) {
        return reject(error);
      }
    });
  }
}
