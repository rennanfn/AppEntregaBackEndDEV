/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable no-async-promise-executor */
/* eslint-disable prettier/prettier */
/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
import { Connection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { ReturnDefault } from '../Interfaces';
import {
  CadMovimentacaoOut,
  MovimentacaoInterface,
} from '../model/Cad_Movimentacao';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import { convertDate2String } from '../utils/dateNow';
import retornoPadrao from '../utils/retornoPadrao';
import CadComodato, {
  ComodatoInterface,
  FiltroDevolucao
} from './../model/Cad_Comodato';
import ShortUniqueId from 'short-unique-id';

interface ComodatoBindOut extends ComodatoInterface {
  cadComodatoOut: string;
}

interface PendenciaComodatoBindOut extends MovimentacaoInterface {
  cadPendenciaOut: string;
}

export interface iTotalComodatoRetirado {
  colaborador_matricula: string;
  nome_funcio: string;
  produto_id: string;
  prod_descricao: string;
  qtd_total_retirada: number;
}

export interface iTotalComodatoDevolvido {
  colaborador_matricula: string;
  nome_funcio: string;
  produto_id: string;
  prod_descricao: string;
  qtd_total_devolvida: number;
}

export interface iTotalComodatoFaltaDevolver {
  colaborador_matricula: string;
  nome_funcio: string;
  produto_id: string;
  prod_descricao: string;
  qtd_falta_devolver: number;
}

export interface iDevolucaoComodato {
  id: string;
  operador_id: string;
  colaborador_matricula: number;
  produto_id: string;
  data_devolucao: Date;
  leitura_qrcode: number;
  qtde_devolvida: number;
}

export interface CadDevolucaoOut {
  id: string;
  operador_id: string;
  colaborador_matricula: number;
  produto_id: string;
  data_devolucao: string;
  leitura_qrcode: number;
  qtde_devolvida: number;
  desativado_em: Date;
  motivo: string;
  cadDevolucaoOut: string;
}

export default class CadComodatoDB extends CadComodato {
  private rowsUndefined(): Error {
    consoleLog(`Erro ao buscar comodato, rows = undefined`, pVerbose.erro);
    return new Error(`Erro ao buscar comodato, rows = undefined`);
  }

  async show(conn: Connection): Promise<ComodatoInterface[]> {
    const sql = `SELECT comodato.produto_id,
                 prod.descricao,
                 comodato.desativado_em
                 FROM app_entrega_comodato comodato
                 INNER JOIN app_entrega_produto prod on prod.id = comodato.produto_id`;

    try{
      const [rows] = await conn.query<RowDataPacket[]>(sql);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      const comodato = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
          atualizado_em:
            formatObject.atualizado_em !== null
              ? convertDate2String(new Date(formatObject.atualizado_em))
              : '',
        } as ComodatoInterface;
      });
      return Promise.resolve(comodato);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async showPendencia(
    conn: Connection,
  ): Promise<CadMovimentacaoOut[]> {
    const sql = `SELECT m.colaborador_matricula,
                 c.nome_funcio,
                 m.produto_id,
                 p.descricao,
                 m.data_retirada,
                 CASE
                 WHEN ce.produto_id IS NOT NULL AND (m.qtde_retirada - COALESCE(ce.qtde_devolvida, 0)) > 0 THEN (m.qtde_retirada - COALESCE(ce.qtde_devolvida, 0))
                 ELSE m.qtde_retirada
                 END AS qtd_a_ser_devolvida
                 FROM app_entrega_movimentacao m
                 LEFT JOIN app_entrega_comodato ac ON ac.produto_id = m.produto_id
                 LEFT JOIN app_entrega_comodato_entrega ce
                 ON ce.produto_id = m.produto_id
                 AND ce.colaborador_matricula = m.colaborador_matricula
                 AND ce.desativado_em IS NULL
                 LEFT JOIN app_entrega_colaboradores c ON c.matricula = m.colaborador_matricula
                 LEFT JOIN app_entrega_produto p ON p.id = m.produto_id
                 WHERE (ac.produto_id IS NOT NULL OR (ac.produto_id IS NULL AND ce.produto_id IS NULL))
                 AND (ce.qtde_devolvida IS NULL OR ce.qtde_devolvida < m.qtde_retirada)`;

      try{
       const [rows] = await conn.query<RowDataPacket[]>(sql);
       if (!Array.isArray(rows)) {
         return Promise.reject(this.rowsUndefined());
       }
       const cadPendencia = rows.map((formatObject: RowDataPacket) => {
         return {
           ...formatObject,
           data_retirada: convertDate2String(new Date(formatObject.data_retirada)),
         } as CadMovimentacaoOut;
       });
       return Promise.resolve(cadPendencia);
     } catch (error) {
       return Promise.reject(error);
     }
  }

  /**
   * Retorna a quantidade total que o colaborador retirou de comodatos agrupado por produto;
   * @param matricula matricula do colaborador
   * @param conn Conexão com o BD
   * @returns Retorna iTotalComodatoRetirado[] se encontrar comodatos que essa matricula retirou, ou um array vazio se não encontrar nada
   */
  async getTotalComodatoRetirado(
    conn: Connection,
    matricula?: number,
  ): Promise<iTotalComodatoRetirado[]> {
    // Não contabiliza os comodatos retirados nos últimos 30 dias.
    const data_corte = new Date();
    data_corte.setDate(data_corte.getDate() - 30);
    let binds: any[] = [];
    let sql = `select mov.colaborador_matricula,
                    col.nome_funcio,
                    mov.produto_id,
                    prod.descricao as prod_descricao,
                    SUM(mov.qtde_retirada) as qtd_total_retirada
                FROM app_entrega_movimentacao mov
                INNER JOIN app_entrega_comodato comodato on comodato.produto_id = mov.produto_id
                INNER JOIN app_entrega_produto prod on prod.id = mov.produto_id
                INNER JOIN app_entrega_colaboradores col on col.matricula = mov.colaborador_matricula
                WHERE comodato.desativado_em IS NULL
                  AND mov.data_retirada <= ?`;
    if (matricula) {
      sql = `${sql} AND mov.colaborador_matricula = ?`;
    }

    sql = `${sql} GROUP BY mov.colaborador_matricula, mov.produto_id, prod.descricao, col.nome_funcio`;

    try {
      if (matricula) {
        binds = [data_corte, matricula];
      } else {
        binds = [data_corte];
      }
        const [rows] = await conn.query<RowDataPacket[]>(sql, binds);
        if (!Array.isArray(rows)) {
          return Promise.reject(this.rowsUndefined());
        }
        const totalComodato = rows.map((formatObject: RowDataPacket) => {
          return {
            ...formatObject,
          } as iTotalComodatoRetirado;
        });
        return Promise.resolve(totalComodato);
      } catch (error) {
        return Promise.reject(error);
      }
   }

  /**
   * Retorna a quantidade total que o colaborador DEVOLVEU de comodatos agrupado por produto;
   * @param matricula matricula do colaborador
   * @param conn Conexão com o BD
   * @returns Retorna iTotalComodatoDevolvido[] se encontrar comodatos que essa matricula DEVOLVEU, ou um array vazio se não encontrar nada
   */
  async getTotalComodatoDevolvido(
    conn: Connection,
    matricula?: number,
  ): Promise<iTotalComodatoDevolvido[]> {
    const bind: number[] = [];
    let sql = `select entrega.colaborador_matricula,
                    col.nome_funcio,
                    entrega.produto_id,
                    prod.descricao as prod_descricao,
                    SUM(entrega.qtde_devolvida) as qtd_total_devolvida
                FROM app_entrega_comodato_entrega entrega
                INNER JOIN app_entrega_comodato comodato on comodato.produto_id = entrega.produto_id
                INNER JOIN app_entrega_produto prod on prod.id = entrega.produto_id
                INNER JOIN app_entrega_colaboradores col on col.matricula = entrega.colaborador_matricula
                WHERE comodato.desativado_em IS NULL
                AND entrega.desativado_em IS NULL`;
    if (matricula) {
      sql = `${sql} AND entrega.colaborador_matricula = ?`;
      bind.push(matricula);
    }
    sql = `${sql} GROUP BY entrega.colaborador_matricula, entrega.produto_id, prod.descricao, col.nome_funcio`;

    try{
      const [rows] = await conn.query<RowDataPacket[]>(sql);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      const comDevolvido = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
        } as iTotalComodatoDevolvido;
      });
      return Promise.resolve(comDevolvido);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async devolucaoComodato(
    obj: iDevolucaoComodato,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const { randomUUID } = new ShortUniqueId({
      dictionary: 'hex',
      length: 36,
    });
    const sql = `INSERT INTO app_entrega_comodato_entrega (id, operador_id, colaborador_matricula, produto_id, data_devolucao, leitura_qrcode, qtde_devolvida)
                 VALUES (?,?,?,?,?,?,?)`;
    const values = [
      obj.id = randomUUID(),
      obj.operador_id,
      obj.colaborador_matricula,
      obj.produto_id,
      obj.data_devolucao,
      obj.leitura_qrcode,
      obj.qtde_devolvida,
    ];

    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 1) {
        return Promise.resolve(
          retornoPadrao(0, `Devolução inserida com sucesso!`),
        );
      } else {
        consoleLog(`Erro ao inserir devolução`, pVerbose.erro);
        return Promise.resolve(retornoPadrao(1, `Erro ao inserir devolução`));
      }
    } catch (error) {
      consoleLog(`Erro ao inserir devolução: ${error}`, pVerbose.erro);
      return Promise.reject(error);
    }
  }

  async showDevolucao(conn: Connection): Promise<CadDevolucaoOut[]> {
    const sql = `SELECT com.id,
                 com.colaborador_matricula,
                 col.nome_funcio,
                 com.produto_id,
                 prod.descricao,
                 com.data_devolucao,
                 com.qtde_devolvida,
                 com.desativado_em,
                 com.motivo
                 FROM app_entrega_comodato_entrega com
                 INNER JOIN app_entrega_produto prod ON prod.id = com.produto_id
                 INNER JOIN app_entrega_colaboradores col ON col.matricula = com.colaborador_matricula
                 ORDER BY com.colaborador_matricula`;

      try {
       const [rows] = await conn.query<RowDataPacket[]>(sql);
       if (!Array.isArray(rows)) {
         return Promise.reject(this.rowsUndefined());
       }
       const showDevolucao = rows.map((formatObject: RowDataPacket) => {
         return {
           ...formatObject,
         } as CadDevolucaoOut;
       });
       return Promise.resolve(showDevolucao);
     } catch (error) {
       return Promise.reject(error);
     }
  }

  async filtroDevolucao(
    filtro: FiltroDevolucao,
    conn: Connection,
  ): Promise<CadDevolucaoOut[] | ReturnDefault> {
    let whereCond = '';
    const bindWhere: any = {};

    if (filtro.colaborador_matricula) {
      whereCond += ` AND com.colaborador_matricula = ?`;
      bindWhere.colaborador_matricula = filtro.colaborador_matricula;
    }
    if (filtro.produto_id) {
      whereCond += ` AND com.produto_id = ?`;
      bindWhere.produto_id = filtro.produto_id;
    }
    if (filtro.data_devolucao_ini && filtro.data_devolucao_fim) {
      whereCond += ` AND TRUNC(com.data_devolucao) >= TO_DATE(?, 'DD/MM/YYYY')
                     AND TRUNC(com.data_devolucao) <= TO_DATE(?, 'DD/MM/YYYY')
                     AND com.desativado_em IS NULL`;
      bindWhere.data_devolucao_ini = convertDate2String(
        new Date(filtro.data_devolucao_ini),
      );
      bindWhere.data_devolucao_fim = convertDate2String(
        new Date(filtro.data_devolucao_fim),
      );
    }
    if (filtro.desativado_em_ini && filtro.desativado_em_fim) {
      whereCond += ` AND TRUNC(com.desativado_em) >= TO_DATE(?, 'DD/MM/YYYY')
                     AND TRUNC(com.desativado_em) <= TO_DATE(?, 'DD/MM/YYYY')`;
      bindWhere.desativado_em_ini = convertDate2String(
        new Date(filtro.desativado_em_ini),
      );
      bindWhere.desativado_em_fim = convertDate2String(
        new Date(filtro.desativado_em_fim),
      );
    }

    // Remova o 'AND' no início da cláusula WHERE
    whereCond = whereCond.trim().substring(3);

    let sql = `SELECT com.id,
               com.colaborador_matricula,
               col.nome_funcio,
               com.produto_id,
               prod.descricao,
               to_char(com.data_devolucao, 'DD/MM/YYYY HH24:MI:SS') AS data_devolucao,
               com.qtde_devolvida,
               to_char(com.desativado_em, 'DD/MM/YYYY HH24:MI:SS') AS desativado_em,
               com.motivo
               FROM app_entrega_comodato_entrega com
               INNER JOIN app_entrega_produto prod ON prod.id = com.produto_id
               INNER JOIN app_entrega_colaboradores col ON col.matricula = com.colaborador_matricula`;

    if (whereCond.length > 0) {
      sql += ` WHERE ${whereCond}`;
    }

    sql += ` GROUP BY com.id, com.colaborador_matricula, col.nome_funcio, com.produto_id,
             prod.descricao, com.data_devolucao, com.qtde_devolvida, com.desativado_em, com.motivo
             ORDER BY com.colaborador_matricula`;

       try {
        const [rows] = await conn.query<RowDataPacket[]>(sql);
        if (!Array.isArray(rows)) {
          return Promise.reject(this.rowsUndefined());
        }
        const filtroDevolucao = rows.map((formatObject: RowDataPacket) => {
          return {
            ...formatObject,
          } as CadDevolucaoOut;
        });
        return Promise.resolve(filtroDevolucao);
      } catch (error) {
        return Promise.reject(error);
      }
  }

  async patch(
    id: string,
    desativado_em: Date,
    motivo: string,
    conn: Connection,
  ): Promise<ReturnDefault> {
      const sql = `UPDATE app_entrega_comodato_entrega SET desativado_em = ?, motivo = ? WHERE id = ?`;
      const values = [
        desativado_em, motivo, id
      ];

      try {
        const [result] = await conn.query<ResultSetHeader>(sql, values);
        if (result.affectedRows === 0) {
          consoleLog(`Devolução não encontrada`, pVerbose.erro);
          return Promise.reject(
            retornoPadrao(1, `Devolução não encontrada`),
          );
        }
        return Promise.resolve(
          retornoPadrao(0, `Devolução atualizada com sucesso!`),
        );
      } catch (error) {
        return Promise.reject(error);
      }
  }
}
