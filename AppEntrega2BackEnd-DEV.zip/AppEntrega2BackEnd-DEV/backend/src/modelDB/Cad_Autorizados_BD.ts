/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable prettier/prettier */
/* eslint-disable no-async-promise-executor */
import { Connection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { ReturnDefault } from '../Interfaces';
import { CadAutorizadosOut, iAutorizados } from '../model/Cad_Autorizados';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import retornoPadrao from '../utils/retornoPadrao';
import { convertDate2String } from '../utils/dateNow';

export default class CadAutorizadosDB {
  private rowsUndefined(): Error {
    consoleLog(
      `Erro ao buscar colaboradores autorizados, rows = undefined`,
      pVerbose.erro,
    );
    return new Error(
      `Erro ao buscar colaboradores autorizados, rows = undefined`,
    );
  }

  async insert(
    obj: iAutorizados,
    conn: Connection,
  ): Promise<ReturnDefault> {

    const sql = `INSERT INTO app_entrega_autorizados (matricula, nome, situacao, data_nascto, sexo, desc_ccusto)
                 VALUES (?,?,?,?,?,?)`;
    const values = [
      obj.matricula,
      obj.nome,
      obj.situacao,
      obj.data_nascto,
      obj.sexo,
      obj.desc_ccusto,
    ];

      try {
        const [result] = await conn.query<ResultSetHeader>(sql, values);
        if (result.affectedRows === 1) {
          return Promise.resolve(
            retornoPadrao(0, `Autorizado inserido com sucesso!`),
          );
        } else {
          consoleLog(`Erro ao inserir autorizado`, pVerbose.erro);
          return Promise.resolve(retornoPadrao(1, `Erro ao inserir autorizado`));
        }
      } catch (error) {
        consoleLog(`Erro ao inserir autorizado: ${error}`, pVerbose.erro);
        return Promise.reject(error);
      }
  }

  async update(
    obj: iAutorizados,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `UPDATE app_entrega_autorizados SET nome = ?, data_nascto = ?, sexo = ?, desc_ccusto = ? WHERE matricula = ?`;
    const values = [
      obj.nome,
      obj.data_nascto,
      obj.sexo,
      obj.desc_ccusto,
      obj.matricula,
    ];
    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 0) {
        consoleLog(`Autorizado não encontrado`, pVerbose.erro);
        return Promise.reject(
          retornoPadrao(1, `Autorizado não encontrada`),
        );
      }
      return Promise.resolve(
        retornoPadrao(0, `Autorizado atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async ativaDesativa(
    situacao: number,
    matricula: number,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `UPDATE app_entrega_autorizados SET situacao = ? WHERE matricula = ?`;
    const values = [situacao, matricula];
    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 0) {
        consoleLog(`Autorizado não encontrado`, pVerbose.erro);
        return Promise.reject(
          retornoPadrao(1, `Autorizado não encontrada`),
        );
      }
      return Promise.resolve(
        retornoPadrao(0, `Autorizado atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async show(conn: Connection): Promise<CadAutorizadosOut[]> {
    const sql = `SELECT matricula, nome, data_nascto, sexo, desc_ccusto, situacao
                 FROM app_entrega_autorizados
                 ORDER BY matricula desc`;
     try {
      const [rows] = await conn.query<RowDataPacket[]>(sql);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      const autorizados = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
          data_nascto: convertDate2String(new Date(formatObject.data_nascto)),
        } as CadAutorizadosOut;
      });
      return Promise.resolve(autorizados);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async find(
    matricula: number,
    conn: Connection,
  ): Promise<CadAutorizadosOut[]> {
    const sql = `SELECT matricula, nome, data_nascto, sexo, situacao
                 FROM app_entrega_autorizados
                 WHERE matricula = ? ORDER BY matricula desc`;
     try {
      const [rows] = await conn.query<RowDataPacket[]>(sql, [matricula]);
      if (typeof rows === 'undefined') {
        return Promise.reject(this.rowsUndefined());
      }
      const filial = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
        } as CadAutorizadosOut;
      });
      return Promise.resolve(filial);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async findAtivaDesativa(
    matricula: number,
    conn: Connection,
  ): Promise<iAutorizados[]> {
    const sql = `SELECT matricula, situacao FROM app_entrega_autorizados WHERE matricula = ?`;
    try {
      const [rows] = await conn.query<RowDataPacket[]>(sql, [matricula]);
      if (typeof rows === 'undefined') {
        return Promise.reject(this.rowsUndefined());
      }
      const filial = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
        } as iAutorizados;
      });
      return Promise.resolve(filial);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async delete(
    matricula: number,
    conn: Connection,
  ): Promise<ReturnDefault> {
      const sql = `DELETE FROM app_entrega_autorizados WHERE matricula = ?`;
      try {
        const rows = await conn.query(sql, [matricula]);

        if (!rows) {
          consoleLog(
            `Erro ao deletar autorizado`,
            pVerbose.erro,
          );
          return Promise.reject(
            retornoPadrao(1, `Erro ao deletar autorizado`),
          );

        } else {
          return Promise.resolve(retornoPadrao(0, `Autorizado deletado com sucesso!`));
        }
      } catch (error) {
        return Promise.reject(error);
      }
  }

  async buscarTokenAut(
    matricula: number,
    conn: Connection,
  ): Promise<iAutorizados[]> {
    const sql = `SELECT col.matricula,
                 tok.token
                 FROM app_entrega_autorizados col
                 INNER JOIN entrega_token tok ON tok.matricula = col.matricula AND tok.desativado = 0
                 WHERE col.matricula = ?`;
    try {
      const [rows] = await conn.query<RowDataPacket[]>(sql, [matricula]);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      const autorizados = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
        } as iAutorizados;
      });
      return Promise.resolve(autorizados);
    } catch (error) {
      return Promise.reject(error);
    }
  }
}
