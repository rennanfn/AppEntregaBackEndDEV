/* eslint-disable camelcase */
/* eslint-disable no-undef */
/* eslint-disable no-async-promise-executor */
/* eslint-disable prettier/prettier */
import { Connection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { ReturnDefault } from '../Interfaces';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import { convertDate2String } from '../utils/dateNow';
import retornoPadrao from '../utils/retornoPadrao';
import CadOperador, {
  CadOperadorOut,
  OperadorInterface,
} from './../model/Cad_Operador';

export default class CadOperadorDB extends CadOperador {
  private rowsUndefined(): Error {
    consoleLog(`Erro ao buscar operador, rows = undefined`, pVerbose.erro);
    return new Error(`Erro ao buscar operador, rows = undefined`);
  }

  async insert(
    obj: OperadorInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `INSERT INTO app_entrega_operador (id, nome, login, senha, criado_em, desativado_em, gerenciador, mobile)
                 VALUES (?,?,?,?,?,?,?,?)`;
    const values = [
      obj.id,
      obj.nome,
      obj.login,
      obj.senha,
      obj.criado_em,
      obj.desativado_em,
      obj.gerenciador,
      obj.mobile,
    ];
    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 1) {
        consoleLog(`Operador inserido com sucesso!`, pVerbose.aviso);
        return Promise.resolve(
          retornoPadrao(0, `Operador inserido com sucesso!`),
        );
      } else {
        consoleLog(`Erro ao inserir operador`, pVerbose.erro);
        return Promise.resolve(retornoPadrao(1, `Erro ao inserir operador`));
      }
    } catch (error) {
      consoleLog(`Erro ao inserir operador: ${error}`, pVerbose.erro);
      return Promise.reject(error);
    }
  }

  async update(
    obj: OperadorInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {
    let sql;
    let values;

    if (obj.senha === undefined) {
      sql = `UPDATE app_entrega_operador SET nome = ?, login = ?, gerenciador = ?, mobile = ?
      WHERE id = ?`;

      values = [
        obj.nome,
        obj.login,
        obj.gerenciador,
        obj.mobile,
        obj.id,
      ];
    } else {
      sql = `UPDATE app_entrega_operador SET nome = ?, login = ?, senha = ?, gerenciador = ?, mobile = ?
      WHERE id = ?`;

      values = [
      obj.nome,
      obj.login,
      obj.senha,
      obj.gerenciador,
      obj.mobile,
      obj.id,
      ];
    }

    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 0) {
        consoleLog(`Operador não encontrado`, pVerbose.erro);
        return Promise.reject(
          retornoPadrao(1, `Operador não encontrado`),
        );
      }
      return Promise.resolve(
        retornoPadrao(0, `Operador atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async ativaDesativa(
    obj: OperadorInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `UPDATE app_entrega_operador SET desativado_em = ? WHERE id = ?`;
    const values = [obj.desativado_em, obj.id];
    try {
      const [result] = await conn.query<ResultSetHeader>(sql, values);
      if (result.affectedRows === 0) {
        consoleLog(`Operador não encontrado`, pVerbose.erro);
        return Promise.reject(
          retornoPadrao(1, `Operador não encontrado`),
        );
      }
      return Promise.resolve(
        retornoPadrao(0, `Operador atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async show(conn: Connection): Promise<CadOperadorOut[]> {
    const sql = `SELECT id, nome, login, criado_em, desativado_em, gerenciador, mobile FROM app_entrega_operador ORDER BY id asc`;
    try {
      const [rows] = await conn.query<RowDataPacket[]>(sql);
      if (!Array.isArray(rows)) {
        return Promise.reject(this.rowsUndefined());
      }
      const operador = rows.map((formatObject: RowDataPacket) => {
        return {
          ...formatObject,
          criado_em: convertDate2String(new Date(formatObject.criado_em)),
          desativado_em:
          formatObject.desativado_em !== null
            ? convertDate2String(new Date(formatObject.desativado_em))
            : null,
        } as CadOperadorOut;
      });
      return Promise.resolve(operador);
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async find(id: string, conn: Connection): Promise<CadOperadorOut[]> {
        const sql = `SELECT id, nome, login, criado_em, desativado_em, gerenciador, mobile FROM app_entrega_operador WHERE id = ? ORDER BY id asc`;
        try {
          const [rows] = await conn.query<RowDataPacket[]>(sql, [id]);
          if (typeof rows === 'undefined') {
            return Promise.reject(this.rowsUndefined());
          }
          const operador = rows.map((formatObject: RowDataPacket) => {
            return {
              ...formatObject,
              criado_em: convertDate2String(new Date(formatObject.criado_em)),
          desativado_em:
          formatObject.desativado_em !== null
            ? convertDate2String(new Date(formatObject.desativado_em))
            : '',
            } as CadOperadorOut;
          });
          return Promise.resolve(operador);
        } catch (error) {
          return Promise.reject(error);
        }
  }

  async findLogin(
    login: string,
    conn: Connection,
  ): Promise<OperadorInterface[]> {
      const sql = `SELECT * FROM app_entrega_operador WHERE login = ?`;
      try {
        const [rows] = await conn.query<RowDataPacket[]>(sql, [login]);
        if (typeof rows === 'undefined') {
          return Promise.reject(this.rowsUndefined());
        }
        const operador = rows.map((formatObject: RowDataPacket) => {
          return {
            ...formatObject,
            criado_em: convertDate2String(new Date(formatObject.criado_em)),
            desativado_em:
            formatObject.desativado_em !== null
              ? convertDate2String(new Date(formatObject.desativado_em))
              : '',
              } as CadOperadorOut;
            });
        return Promise.resolve(operador);
      } catch (error) {
        return Promise.reject(error);
      }
  }

  async findAtivaDesativa(
    id: string,
    conn: Connection,
  ): Promise<OperadorInterface[]> {
      const sql = `SELECT id, desativado_em FROM app_entrega_operador WHERE id = ?`;
      try {
        const [rows] = await conn.query<RowDataPacket[]>(sql, [id]);
        if (typeof rows === 'undefined') {
          return Promise.reject(this.rowsUndefined());
        }
        const operador = rows.map((formatObject: RowDataPacket) => {
          return {
            ...formatObject,
              } as CadOperadorOut;
            });
        return Promise.resolve(operador);
      } catch (error) {
        return Promise.reject(error);
      }
  }
}
