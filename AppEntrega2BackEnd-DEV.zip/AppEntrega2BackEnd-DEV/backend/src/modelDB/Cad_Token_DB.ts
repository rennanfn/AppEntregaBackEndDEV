/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable prefer-const */
/* eslint-disable dot-notation */
/* eslint-disable no-undef */
/* eslint-disable camelcase */
/* eslint-disable no-unused-vars */
/* eslint-disable no-async-promise-executor */
/* eslint-disable prettier/prettier */
import { Connection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { ReturnDefault } from '../Interfaces';
import CadToken, { TokenInterface } from '../model/Cad_Token';
import { MySqlConnection } from '../model/MySqlConnection';
import { consoleLog, pVerbose } from '../utils/consoleLog';
import convertLowerCase from '../utils/convertLowerCase';
import retornoPadrao from '../utils/retornoPadrao';
import { gerarTokenColaborador } from '../utils/token';

export default class CadTokenDB extends CadToken {
  private rowsUndefined(): Error {
    consoleLog(`Erro ao buscar token, rows = undefined`, pVerbose.erro);
    return new Error(`Erro ao buscar token, rows = undefined`);
  }

  async verificaToken(
    matricula: number,
    conn: Connection,
  ): Promise<TokenInterface[]> {
    const sql = `SELECT token, sequencial FROM entrega_token WHERE matricula = ? AND desativado = 0`;

    const result = await conn.execute<RowDataPacket[]>(sql, [matricula]);
    const token = result[0] as TokenInterface[];

    if (typeof token === 'undefined') {
      return Promise.reject(this.rowsUndefined());
    }
    return Promise.resolve(convertLowerCase(token));
  }

  async update(
    matricula: number,
    sequencial: number,
    token: string,
    desativado: number,
    conn: Connection,
  ): Promise<ReturnDefault> {
    try {
      const sqlUpdate = `UPDATE entrega_token SET desativado = 1 WHERE matricula = ? AND desativado = 0`;
      const bindsUpdate = [matricula];
      await conn.execute(sqlUpdate, bindsUpdate);

      let id

      const addID = await conn.execute(
        `SELECT MAX (id) AS id from entrega_token`,
      );
      if (!addID) {
        consoleLog(`Erro ao buscar id, rows = undefined`, pVerbose.erro);
      } else {
        let maxId = addID[0];
        let objID = maxId[0].id;
        id = objID + 1;
      }

      const sqlInsert = `
      INSERT INTO entrega_token (id, matricula, sequencial, token, desativado)
      VALUES (?, ?, ?, ?, ?)
      `;

      const bindsInsert = [id, matricula, sequencial, token, desativado];

      await conn.query(sqlInsert, bindsInsert);

      consoleLog(`Token atualizado com sucesso!`, pVerbose.aviso);
      return Promise.resolve(retornoPadrao(0, `Token atualizado com sucesso!`));
    } catch (error) {
      return Promise.reject(error);
    }
  }

  async validaToken(
    token: string,
    conn: Connection,
  ): Promise<TokenInterface[]> {
    const sql = `SELECT t.id, t.matricula, f.nome_funcio, t.token, t.sequencial
                  FROM entrega_token t
                  INNER JOIN app_entrega_colaboradores f on f.matricula = t.matricula
                  WHERE t.token = ? AND t.desativado = 0`;

    const result = await conn.execute<RowDataPacket[]>(sql, [token]);

    const returnToken = result[0] as TokenInterface[];

    if (typeof returnToken === 'undefined') {
      return Promise.reject(this.rowsUndefined());
    }
    const tokens = convertLowerCase(returnToken);
    if (tokens.length <= 0)
      return Promise.reject(
        retornoPadrao(
          1,
          'Erro na leitura do QrCode, entrar em contato com o RH.',
        ),
      );
    return Promise.resolve(tokens);
  }

  async generatorTokensNewFunc(): Promise<ReturnDefault> {
    const conn = await MySqlConnection.getConnection();
    if(!conn){
      consoleLog(`Erro ao abrir conexão com o MySQL!`, pVerbose.erro);
    }
    return new Promise(async (resolve, reject) => {
      const resultSemToken =
        `SELECT colab.matricula from app_entrega_colaboradores colab ` +
        `WHERE colab.matricula NOT IN (select col.matricula from app_entrega_colaboradores col ` +
        `inner join entrega_token token on token.matricula = col.matricula) `;

      try {
        const result = await conn.execute<RowDataPacket[]>(resultSemToken, []);
        consoleLog(
          'Total de colaboradores sem Token: ' + result,
          pVerbose.erro,
        );

        const funcToken = result[0];
        if (!funcToken || funcToken.length <= 0)
          consoleLog(`Não há colaborador sem token!`, pVerbose.erro);
        else {
          const objsInsert = funcToken.map(row => ({
            matricula: Number(row['matricula']),
            newSequencial: 1,
            token: gerarTokenColaborador({
              matricula: Number(row['matricula']),
              token: '',
              sequencial: 1,
            }),
          }));

          consoleLog(
            'Total de itens a serem incluídos: ' + objsInsert.length,
            pVerbose.aviso,
          );

          const sql =
            'insert into entrega_token (matricula, sequencial, token, desativado) ' +
            'values(?, ?, ?, 0)';
          const values = objsInsert;

          try {
            await conn.query(sql, values);
            consoleLog(
              `Token inserido com sucesso para ` +
                objsInsert.length +
                ` colaborador(es)`,
              pVerbose.aviso,
            );
          } catch (error) {
            reject(error);
          }
        }
      } catch (error) {
        return reject(error);
      }
    });
  }

  async findAtivaDesativa(
    id: number,
    conn: Connection,
  ): Promise<TokenInterface[]> {
      const sql = `SELECT id, desativado FROM entrega_token WHERE id = ?`;
      try {
        const [rows] = await conn.query<RowDataPacket[]>(sql, [id]);
          if (typeof rows === 'undefined') {
            return Promise.reject(this.rowsUndefined());
          }
          const token = rows.map((formatObject: RowDataPacket) => {
            return {
              ...formatObject,
            } as TokenInterface;
          });
          return Promise.resolve(token);
      } catch (error) {
        return Promise.reject(error);
      }
  }

  async ativaDesativa(
    token: TokenInterface,
    conn: Connection,
  ): Promise<ReturnDefault> {
    const sql = `UPDATE entrega_token SET desativado = ? WHERE id = ?`;
    const values = [token.desativado, token.id];
    try {
      const [result] = await conn.execute<ResultSetHeader>(sql, values);
      if (result.affectedRows === 0) {
        return Promise.reject(this.rowsUndefined());
      }
      return Promise.resolve(
        retornoPadrao(0, `Token atualizado com sucesso!`),
      );
    } catch (error) {
      return Promise.reject(error);
    }
  }
}
