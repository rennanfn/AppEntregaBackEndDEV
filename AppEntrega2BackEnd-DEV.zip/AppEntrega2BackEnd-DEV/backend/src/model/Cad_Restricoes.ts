/* eslint-disable prettier/prettier */

import { z } from 'zod';
import { ReturnDefault } from '../Interfaces';
import { Connection } from 'mysql2/promise';

export const restricoesSchema = z.object({
  id: z.string({ required_error: 'Campo Obrigatório!' }).optional(),
  matricula: z.number({ required_error: 'Campo Obrigatório' }).optional(),
  produto_id: z.string({ required_error: 'Campo Obrigatório' }).optional(),
  motivo: z.string({ required_error: 'Campo Obrigatório!' }).optional(),
  desativado_em: z.date().optional(),
});

export type RestricoesZ = z.infer<typeof restricoesSchema>;

export interface RestricoesInterface {
  id?: string | undefined;
  matricula?: number | undefined;
  produto_id?: string | undefined;
  motivo?: string | undefined;
  desativado_em?: Date | string | undefined | null;
}

export interface CadRestricoesOut extends RestricoesInterface {
  desativado_em: string;
}

export default abstract class CadRestricoes {
  private restricoes: RestricoesInterface;

  constructor(obj: RestricoesInterface) {
    this.restricoes = obj;
  }

  getRestricoesObj(): RestricoesInterface {
    return this.restricoes;
  }

  getId(): string | undefined {
    return this.restricoes.id;
  }

  getMatricula(): number | undefined {
    return this.restricoes.matricula;
  }

  getProdutoId(): string | undefined {
    return this.restricoes.produto_id;
  }

  getMotivo(): string | undefined {
    return this.restricoes.motivo;
  }

  getDesativadoEm(): Date | string | undefined | null {
    return this.restricoes.desativado_em;
  }

  abstract insert(
    obj: RestricoesZ,
    conn: Connection,
  ): Promise<ReturnDefault>;

  abstract update(
    obj: RestricoesZ,
    conn: Connection,
  ): Promise<ReturnDefault>;

  abstract show(conn: Connection): Promise<CadRestricoesOut[]>;

  abstract find(
    id: string,
    conn: Connection,
  ): Promise<CadRestricoesOut[]>;
}
