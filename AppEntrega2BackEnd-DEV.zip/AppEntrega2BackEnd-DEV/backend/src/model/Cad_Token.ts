import { z } from 'zod';

export const tokenSchema = z.object({
  id: z.number({ required_error: 'Campo Obrigatório' }).optional(),
  matricula: z.number({ required_error: 'Campo Obrigatório' }).optional(),
  sequencial: z.number({ required_error: 'Campo Obrigatório' }).optional(),
  token: z.string({ required_error: 'Campo Obrigatório' }).optional(),
  desativado: z.number({ required_error: 'Campo Obrigatório' }).optional(),
});

export type TokenZ = z.infer<typeof tokenSchema>;

export interface TokenInterface {
  id?: number | undefined;
  matricula?: number | undefined;
  nome_funcio?: string | undefined;
  sequencial?: number | undefined;
  token?: string | undefined;
  desativado?: number | undefined;
}

export default abstract class CadToken {
  private token: TokenInterface;

  constructor(obj: TokenInterface) {
    this.token = obj;
  }

  getTokenObj(): TokenInterface {
    return this.token;
  }

  getId(): number | undefined {
    return this.token.id;
  }

  getMatricula(): number | undefined {
    return this.token.matricula;
  }

  getSequencial(): number | undefined {
    return this.token.sequencial;
  }

  getToken(): string | undefined {
    return this.token.token;
  }

  getDesativado(): number | undefined {
    return this.token.desativado;
  }
}
