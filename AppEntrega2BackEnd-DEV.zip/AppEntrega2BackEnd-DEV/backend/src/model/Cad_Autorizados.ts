/* eslint-disable prettier/prettier */
import { z } from 'zod';

export const campoObrigatorio = 'obrigatório';

export const autorizadosSchema = z.object({
  matricula: z
  .number({ required_error: campoObrigatorio }),
  nome: z
    .string({ required_error: campoObrigatorio })
    .min(1, { message: 'O nome deve ter deve ter no mímino 1 caracter' })
    .max(50, { message: 'O nome deve ter no máximo 50 caracteres' }),
  situacao: z.number({ required_error: campoObrigatorio })
  .refine((value) => value === 0 || value === 1, {
    message: 'Campo situacao: Caracter inválido. O valor deve ser 0 ou 1',
  }),
  data_nascto: z.date().optional(),
  sexo: z.string({ required_error: campoObrigatorio }),
  desc_ccusto: z.string({ required_error: campoObrigatorio }),
});

export type iAutorizadosZ = z.infer<typeof autorizadosSchema>;

export interface iAutorizados {
  matricula?: number;
  nome: string;
  situacao: number;
  data_nascto: Date | string;
  sexo: string;
  desc_ccusto: string;
}

export interface CadAutorizadosOut extends iAutorizados {
  data_nascto: string;
}

// export default abstract class CadAutorizados {
//   private autorizados: AutorizadosInterface;

//   constructor(obj: AutorizadosInterface) {
//     this.autorizados = obj;
//   }

//   getAutorizadosObj(): AutorizadosInterface {
//     return this.autorizados;
//   }

//   getMatricula(): number | undefined {
//     return this.autorizados.matricula;
//   }

//   getNome(): string | undefined {
//     return this.autorizados.nome;
//   }

//   getEmail(): string | undefined {
//     return this.autorizados.email;
//   }

//   getSituacao(): number | undefined {
//     return this.autorizados.situacao;
//   }

//   getCpf(): string | undefined {
//     return this.autorizados.cpf;
//   }

//   getRg(): string | undefined {
//     return this.autorizados.rg;
//   }

//   getDataNascto(): Date | string | undefined {
//     return this.autorizados.data_nascto;
//   }

//   getSexo(): string | undefined {
//     return this.autorizados.sexo;
//   }

//   getDeficiente(): string | undefined {
//     return this.autorizados.deficiente;
//   }

//   getInternoOuExterno(): string | undefined {
//     return this.autorizados.internoouexterno;
//   }

//   getdesc_ccusto(): string | undefined {
//     return this.autorizados.desc_ccusto;
//   }

//   getDesdesc_ccusto(): string | undefined {
//     return this.autorizados.desc_desc_ccusto;
//   }

//   getFilial(): number | undefined {
//     return this.autorizados.filial;
//   }

//   abstract insert(
//     obj: AutorizadosZ,
//     conn: oracledb.Connection,
//   ): Promise<ReturnDefault>;

//   abstract update(
//     obj: AutorizadosZ,
//     conn: oracledb.Connection,
//   ): Promise<ReturnDefault>;

//   abstract show(conn: oracledb.Connection): Promise<CadAutorizadosOut[]>;

//   abstract find(
//     matricula: number,
//     conn: oracledb.Connection,
//   ): Promise<CadAutorizadosOut[]>;

//   abstract findPatch(
//     matricula: number,
//     conn: oracledb.Connection,
//   ): Promise<AutorizadosInterface[]>;
// }
