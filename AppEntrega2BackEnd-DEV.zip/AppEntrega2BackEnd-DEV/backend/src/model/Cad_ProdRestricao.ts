import { Connection } from 'mysql2/promise';

export enum pBolean {
  'nao' = 0,
  'sim' = 1,
}
export interface iProdSemRestricao {
  id: string;
  descricao: string;
  entrega_com_restricao_comodato: pBolean;
  retira_com_menos_trinta_dias: pBolean;
  periodicidade_id: string;
  desc_periodicidade: string;
  qtd_dias_periodo: number;
  existe_pendencia_comodato: pBolean;
  qtd_max_retirada: number;
  entrega_somente_aniversario: pBolean;
}

export interface iVerificaPeriodicidade {
  id_produto: string;
  pode_retirar: boolean;
  qtd_ja_retirada: number;
}

export interface iQtdProdsRetirados {
  colaborador_matricula: string;
  produto_id: string;
  total_retirado: number;
}

export abstract class CadProdRestricao {
  /**
   * Busca todos os produtos que o colaborador pode retirar e não tem restrição na tabela app_entrega_restricoes
   * @param matricula matricula do colaborador
   * @param conn conexão com o BD
   * @returns iProdSemRestricao[] se encontrar ou undefined se não encontrar;
   */
  abstract getProdutosSemRestricao(
    matricula: number,
    conn: Connection,
  ): Promise<iProdSemRestricao[] | undefined>;

  /**
   * Recebe uma lista de produtos e verifica quais deles não pode ser entregue se o colaborador entrou a menos de 30 dias.
   * @param produtos produtos serão verificados se o colaborador pode retirar
   * @param matricula matrica do colaborador
   * @param conn conexão com o BD
   * @returns Se tiver algum produto que o colaborador possa retirar retorna iProdSemRestricao[], caso contrário retorna array vazio
   */
  abstract ProdTrintaDias(
    produtos: iProdSemRestricao[],
    matricula: number,
    conn: Connection,
  ): Promise<iProdSemRestricao[]>;

  /**
   * Recebe uma lista de produtos e verifica quais deles não pode ser entregue se o colaborador tem pendência de comodato.
   * @param produtos produtos serão verificados se o colaborador pode retirar
   * @param matricula matrica do colaborador
   * @param conn conexão com o BD
   * @returns Se tiver algum produto que o colaborador possa retirar retorna iProdSemRestricao[], caso contrário retorna array vazio
   */
  abstract ProdPendComodato(
    produtos: iProdSemRestricao[],
    matricula: number,
    conn: Connection,
  ): Promise<iProdSemRestricao[]>;

  /**
   * Verifica se o colaborador já reitou o produto informado levando em conta a periodicidade do mesmo, caso ele já tenha retirado ajusta a quantidade máxima (Exemplo, ele pode retirar no máxima 3 camisas, mas ele já retirou 2, então agora ele só pode retirar mais 1).
   * @param produto Produto a ser verificado
   * @param conn Conexão com o BD
   * @returns Retorna o objeto iVerificaPeriodicidade com o campo pode_retirar true se não encontrar algum problema, e o campo qtd_ja_retirada com a quantidade total desse produto que ele retirou dentro do período informado.
   */
  abstract VerificaSeJaRetirouNaPeriodicidade(
    matricula: number,
    produto: iProdSemRestricao,
    conn: Connection,
  ): Promise<iVerificaPeriodicidade>;
}
