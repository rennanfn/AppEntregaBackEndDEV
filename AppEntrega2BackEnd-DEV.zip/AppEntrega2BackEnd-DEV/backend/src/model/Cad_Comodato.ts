export interface ComodatoInterface {
  produto_id?: string | undefined;
  desativado_em?: Date | undefined | string;
}

export interface FiltroDevolucao {
  colaborador_matricula?: number | undefined;
  produto_id?: string | undefined;
  data_devolucao_ini?: Date | string | undefined;
  data_devolucao_fim?: Date | string | undefined;
  desativado_em_ini?: Date | undefined;
  desativado_em_fim?: Date | undefined;
}

export interface CadComodatoOut extends ComodatoInterface {
  desativado_em: string;
}

export default abstract class CadComodato {
  private comodato: ComodatoInterface;

  constructor(obj: ComodatoInterface) {
    this.comodato = obj;
  }

  getComodatoObj(): ComodatoInterface {
    return this.comodato;
  }

  getProdutoId(): string | undefined {
    return this.comodato.produto_id;
  }

  getDesativadoEm(): Date | undefined | string {
    return this.comodato.desativado_em;
  }
}
