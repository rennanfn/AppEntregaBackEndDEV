/* eslint-disable prettier/prettier */
import { Connection } from 'mysql2/promise';
import { z } from 'zod';
import { ReturnDefault } from '../Interfaces';

export const maxRetiradaSchemaProduto = z.object({
  produto_id: z
    .string({ required_error: 'Campo Obrigatório!' })
    .min(1)
    .max(36)
    .optional(),
  criado_em: z.date().optional(),
  qtd_max_retirada: z
    .number({ required_error: 'Campo Obrigatório' })
    .optional(),
  periodo_liberado_retirada_ini: z.string(),
  periodo_liberado_retirada_fim: z.string(),
});

export const maxRetiradaSchemaHttp = z.object({
  matricula: z.number({ required_error: 'Campo Obrigatório!' }).optional(),
  produtos: z.array(maxRetiradaSchemaProduto),
});

export const maxRetiradaSchemaHttpArray = z.array(maxRetiradaSchemaHttp);

export const maxRetiradaSchema = z.object({
  matricula: z.number({ required_error: 'Campo Obrigatório!' }).optional(),
  produto_id: z
    .string({ required_error: 'Campo Obrigatório!' })
    .min(1)
    .max(36)
    .optional(),
  criado_em: z.string().optional(),
  qtd_max_retirada: z
    .number({ required_error: 'Campo Obrigatório' })
    .optional(),
  periodo_liberado_retirada_ini: z.string(),
  periodo_liberado_retirada_fim: z.string(),
});

export type MaxRetiradaZ = z.infer<typeof maxRetiradaSchema>;

export interface MaxRetiradaInterface {
  matricula?: number | undefined;
  produto_id?: string | undefined;
  criado_em?: Date | string;
  qtd_max_retirada?: number | undefined;
  periodo_liberado_retirada_ini?: Date | undefined | string;
  periodo_liberado_retirada_fim?: Date | undefined | string;
}

export interface CadMaxRetiradaOut extends MaxRetiradaInterface {
  criado_em: string;
  periodo_liberado_retirada_ini: string;
  periodo_liberado_retirada_fim: string;
  prod_descricao: string;
}

export default abstract class CadMaxRetirada {
  private maxRetirada: MaxRetiradaInterface;

  constructor(obj: MaxRetiradaInterface) {
    this.maxRetirada = obj;
  }

  getMaxRetiradaObj(): MaxRetiradaInterface {
    return this.maxRetirada;
  }

  getMatricula(): number | undefined {
    return this.maxRetirada.matricula;
  }

  getProdutoId(): string | undefined {
    return this.maxRetirada.produto_id;
  }

  getCriadoEm(): Date | undefined | string {
    return this.maxRetirada.criado_em;
  }

  getQtdMaxRetirada(): number | undefined {
    return this.maxRetirada.qtd_max_retirada;
  }

  getPeriodoLiberadoRetiradaIni(): Date | string | undefined {
    return this.maxRetirada.periodo_liberado_retirada_ini;
  }

  getPeriodoLiberadoRetiradaFim(): Date | string | undefined {
    return this.maxRetirada.periodo_liberado_retirada_ini;
  }

  abstract insert(
    obj: MaxRetiradaInterface,
    conn: Connection,
  ): Promise<ReturnDefault>;

  abstract update(
    obj: MaxRetiradaInterface,
    conn: Connection,
  ): Promise<ReturnDefault>;

  abstract show(conn: Connection): Promise<CadMaxRetiradaOut[]>;

  abstract find(
    matricula: number,
    conn: Connection,
  ): Promise<CadMaxRetiradaOut[]>;
}
