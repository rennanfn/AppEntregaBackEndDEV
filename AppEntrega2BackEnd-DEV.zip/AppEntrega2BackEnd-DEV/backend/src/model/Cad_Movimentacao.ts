/* eslint-disable prettier/prettier */
import { Connection } from 'mysql2/promise';
import { z } from 'zod';
import { ReturnDefault } from '../Interfaces';

export const movimentacaoSchema = z.array(
  z.object({
    id: z.string({ required_error: 'Campo Obrigatório!' }).optional(),
    operador_id: z.string({ required_error: 'Campo Obrigatório' }).optional(),
    colaborador_matricula: z.number({ required_error: 'Campo Obrigatório!' }),
    produto_id: z.string({ required_error: 'Campo Obrgatório' }),
    data_retirada: z.date().optional().optional(),
    leitura_qrcode: z
      .number({ required_error: 'Campo Obrigatório' })
      .optional(),
    qtde_retirada: z.number({ required_error: 'Campo Obrigatório' }),
    desativado_em: z.date({ required_error: 'Campo Obrigatório' }).optional(),
    motivo: z.string({ required_error: 'Campo Obrigatório' }).optional(),
    // recebedor_id: z.string().optional(),
    // recebedor_descricao: z.string().optional(),
  }),
);

export type MovimentacaoZ = z.infer<typeof movimentacaoSchema>;

export interface MovimentacaoInterface {
  id?: string | undefined;
  operador_id?: string | undefined;
  colaborador_matricula?: number | undefined;
  produto_id?: string | undefined;
  data_retirada?: Date | string | undefined;
  leitura_qrcode?: number | undefined;
  qtde_retirada?: number | undefined;
  desativado_em?: Date | string | undefined;
  motivo?: string | undefined;
  // recebedor_id?: string | undefined;
  // recebedor_descricao?: string | undefined;
}

export interface FiltroMovimentacao {
  colaborador_matricula?: number | undefined;
  nome_funcio?: string | undefined;
  produto_id?: string | undefined;
  data_retirada_ini?: Date | string | undefined;
  data_retirada_fim?: Date | string | undefined;
  desativado_em_ini?: Date | undefined;
  desativado_em_fim?: Date | undefined;
}

export interface CadMovimentacaoOut extends MovimentacaoInterface {
  data_retirada: string;
  desativado_em: string;
}

export default abstract class CadMovimentacao {
  private movimentacao: MovimentacaoInterface;

  constructor(obj: MovimentacaoInterface) {
    this.movimentacao = obj;
  }

  getMovimentacaoObj(): MovimentacaoInterface {
    return this.movimentacao;
  }

  getId(): string | undefined {
    return this.movimentacao.id;
  }

  getOperadorId(): string | undefined {
    return this.movimentacao.operador_id;
  }

  getColaboradorMatricula(): number | undefined {
    return this.movimentacao.colaborador_matricula;
  }

  getProdutoId(): string | undefined {
    return this.movimentacao.produto_id;
  }

  getDataRetirada(): Date | string | undefined {
    return this.movimentacao.data_retirada;
  }

  getLeituraQrCode(): number | undefined {
    return this.movimentacao.leitura_qrcode;
  }

  getQtdeRetirada(): number | undefined {
    return this.movimentacao.qtde_retirada;
  }

  getDesativadoEm(): Date | string | undefined {
    return this.movimentacao.desativado_em;
  }

  getMotivo(): string | undefined {
    return this.movimentacao.motivo;
  }

  // getRecebedorId(): string | undefined {
  //   return this.movimentacao.recebedor_id;
  // }

  // getRecebedorDescricao(): string | undefined {
  //   return this.movimentacao.recebedor_descricao;
  // }
  abstract insert(
    obj: MovimentacaoInterface,
    conn: Connection,
  ): Promise<ReturnDefault>;

  abstract show(conn: Connection): Promise<CadMovimentacaoOut[]>;
}
