export default {
  host: process.env.DB_DEV_HOST_ENTREGA_MYSQL, // Endereço do servidor do MySQL
  user: process.env.DB_DEV_USER_NAME_ENTREGA_MYSQL, // Nome de usuário do MySQL
  password: process.env.DB_DEV_USER_PASSWORD_ENTREGA_MYSQL, // Senha do MySQL
  database: process.env.DB_DEV_CONNECT_DESCRIPTOR_ENTREGA_MYSQL, // Nome do banco de dados MySQL
  waitForConnections: true, // Aguardar por conexões quando o pool estiver esgotado
  connectionLimit: 120, // Limite máximo de conexões no pool
};
