/* eslint-disable @typescript-eslint/no-non-null-assertion */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
import { ErroGeneral } from './../model/ErroGeneral';
/* eslint-disable camelcase */
import * as CryptoJS from 'crypto-js';
import { NextFunction, Request, Response } from 'express';
import jwt, { TokenExpiredError } from 'jsonwebtoken';
import { Token, TokenColaborador } from '../Interfaces';
import { MySqlConnection } from '../model/MySqlConnection';
import CadOperadorDB from '../modelDB/Cad_Operador_DB';
import { consoleLog, pVerbose } from './consoleLog';
import retornoPadrao from './retornoPadrao';

interface DataToRefresh {
  id: string;
  login: string;
}

function encryptToken(obj: string): string {
  // consoleLog(`Criptografando payload token`, pVerbose.aviso);
  const payload_key =
    typeof process.env.PAYLOAD_KEY !== 'undefined'
      ? process.env.PAYLOAD_KEY
      : '';

  if (payload_key === '') return '';
  const key = CryptoJS.enc.Utf8.parse(payload_key);
  const iv = CryptoJS.enc.Utf8.parse(payload_key);

  const encrypted = CryptoJS.AES.encrypt(
    CryptoJS.enc.Utf8.parse(obj.toString()),
    key,
    {
      keySize: 128 / 8,
      iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    },
  );
  // consoleLog(`Payload criptogrado com sucesso!`, pVerbose.aviso);
  return encrypted.toString();
}

function gerarToken(obj: Token): string {
  const secretKey =
    typeof process.env.TOKEN_SECRET_ENTREGA !== 'undefined'
      ? process.env.TOKEN_SECRET_ENTREGA
      : '';

  if (secretKey === '') return '';

  const corpoToken = JSON.stringify(obj);
  const newPayload = encryptToken(corpoToken);

  if (newPayload === '') return '';
  const tokenEncrypto = {
    tokenEnc: newPayload,
  };

  const tokenExpireTime = process.env.TOKEN_EXPIRES_IN_MINUTE ?? '60';
  const jwtOptions: jwt.SignOptions = {
    expiresIn: `${tokenExpireTime}m`,
  };
  const token = jwt.sign(tokenEncrypto, secretKey, jwtOptions);

  return token;
}

function gerarTokenColaborador(obj: TokenColaborador): string {
  const secretKey =
    typeof process.env.QRCODE_SECRET !== 'undefined'
      ? process.env.QRCODE_SECRET
      : '';

  if (secretKey === '') return '';

  const corpoToken = JSON.stringify(obj);
  const newPayload = encryptToken(corpoToken);

  if (newPayload === '') return '';

  const tokenEncrypto = {
    tokenEnc: newPayload,
    sub: obj.matricula,
    seq: obj.sequencial
  };

  const token = jwt.sign(tokenEncrypto, secretKey);

  return token;
}

function decryptToken(encrypted: string): string {
  // consoleLog(`Descriptografando payload token`, pVerbose.aviso);
  const payload_key =
    typeof process.env.PAYLOAD_KEY !== 'undefined'
      ? process.env.PAYLOAD_KEY
      : '';

  if (payload_key === '') return '';

  const key = CryptoJS.enc.Utf8.parse(payload_key);
  const iv = CryptoJS.enc.Utf8.parse(payload_key);

  const decrypted = CryptoJS.AES.decrypt(encrypted.toString(), key, {
    keySize: 128 / 8,
    iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });
  // consoleLog(`Payload descriptogrfado com sucesso!`, pVerbose.aviso);
  return decrypted.toString(CryptoJS.enc.Utf8);
}

function validLifeTimeToken(iat: number, exp: number): boolean {
  const tokenExpireTime = process.env.TOKEN_EXPIRES_IN_MINUTE ?? '60';
  const tokenExpireInMs = Number(tokenExpireTime) * 60000;

  const timeDiff = Math.abs(+new Date(exp) - +new Date(iat)) * 1000;
  if (Math.trunc(timeDiff) <= tokenExpireInMs) return true;
  return false;
}

function isRefreshable(expiredAt: string): boolean {
  // Pega a diferença entre a hora atual e a hora que o token expirou,
  // divide por 60000 para transformar milisegundos em minuto.
  const timeDiff = Math.abs(+new Date() - +new Date(expiredAt)) / 60000;
  // Se o token expirou a menos de 10 minutos então pode ser atualizado.
  if (Math.trunc(timeDiff) <= 10) {
    return true;
  }
  return false;
}

function getDataToRefresh(token: string): DataToRefresh | null {
  try {
    const secretKey =
      typeof process.env.TOKEN_SECRET_ENTREGA !== 'undefined'
        ? process.env.TOKEN_SECRET_ENTREGA
        : '';

    const payloadTokenEnc = jwt.verify(token, secretKey) as jwt.JwtPayload;
    if (payloadTokenEnc) {
      // Se passar no verify é sinal que o token não esta expirado então não pode fazer refresh,
      // descriptografa o token para pegar o id para o log
      const tokenEncript = jwt.decode(token) as jwt.JwtPayload;
      if (typeof tokenEncript?.tokenEnc === 'undefined') return null;

      const tokenDecript = decryptToken(tokenEncript.tokenEnc);
      if (tokenDecript.length <= 0) return null;

      const { id }: DataToRefresh = JSON.parse(tokenDecript);
      consoleLog(
        `Tentativa de refresh sem estar expirado - token: ${payloadTokenEnc}`,
        1,
      );
      return null;
    }
  } catch (error) {
    // Verifica se foi erro de expiração e se pode atualizar o token
    if (error instanceof TokenExpiredError) {
      if (
        error?.name === 'TokenExpiredError' &&
        isRefreshable(String(error.expiredAt))
      ) {
        const tokenEncript = jwt.decode(token) as jwt.JwtPayload;
        if (typeof tokenEncript?.tokenEnc === 'undefined') return null;

        const tokenDecript = decryptToken(tokenEncript.tokenEnc);
        if (tokenDecript.length <= 0) return null;

        const { login, id }: DataToRefresh = JSON.parse(tokenDecript);
        if (typeof login === 'undefined' || typeof id === 'undefined') {
          consoleLog(`Token sem login ou id, refresh cancelado`, 1);
          return null;
        }
        return { login, id };
      }
    }
  }
  return null;
}

export const validaToken = async (
  req: Request,
  resp: Response,
  next: NextFunction,
) => {
  const url =  req.baseUrl ?? req.url ?? '';

  // consoleLog('Validando Token', pVerbose.aviso);
  const token = req.headers.authorization;
  if (!token) {
    consoleLog(`Request sem token`, pVerbose.erro);
    return resp
      .status(403)
      .json(retornoPadrao(1, 'Sessão expirada. Realize a autenticação novamente.'));
  }

  try {
    const secretKey = process.env.TOKEN_SECRET_ENTREGA || '';

    const payloadTokenEnc = jwt.verify(token, secretKey) as jwt.JwtPayload;

    if (!validLifeTimeToken(payloadTokenEnc.iat!, payloadTokenEnc.exp!)) {
      consoleLog(`Claims inválidas`, pVerbose.erro);
      return resp
        .status(403)
        .json(retornoPadrao(1, 'Sessão expirada. Realize a autenticação novamente.'));
    }

    const decoded = decryptToken(payloadTokenEnc.tokenEnc);

    if (!decoded) {
      consoleLog(`Não foi possível descriptografar o token`, pVerbose.erro);
      return resp
        .status(403)
        .json(
          retornoPadrao(1, `Sessão expirada. Realize a autenticação novamente`),
        );
    }
    const tokenDados = JSON.parse(decoded) as Token;
    if (!tokenDados.id) {
      consoleLog(`Token sem o parâmetro id`, pVerbose.erro);
      return resp
        .status(403)
        .json(
          retornoPadrao(1, `Sessão expirada. Realize a autenticação novamente`),
        );
    }

    let connection;

    try {
      connection = await MySqlConnection.getConnection();
      const cadOperador = new CadOperadorDB({});
      const operador = await cadOperador.findLogin(tokenDados.login, connection);

      if (operador.length === 0) {
        consoleLog(`Operador não encontrado!`, pVerbose.erro);
        return resp.status(403).json(retornoPadrao(1, `Sessão Expirada!`));
      }

      req.customProperties = {
        login: tokenDados.login,
        id: tokenDados.id,
        token_data: tokenDados,
      };
    } catch (error) {
      consoleLog(`Erro ao buscar operador`, pVerbose.erro);
      return resp.status(403).json(retornoPadrao(1, `Token Inválido!`));
    } finally {
      MySqlConnection.closeConnection(connection);
    }
    next();
  } catch (error) {
    if (error instanceof TokenExpiredError) {
      consoleLog(
        `Token expirado mas pode ser atualizado. Expirou em: ${error?.expiredAt} - url: ${url}`,
        pVerbose.aviso,
      );
      return resp
        .status(401)
        .json(
          retornoPadrao(
            1,
            `Sessão Expirada. Realize novamente a autenticação.`,
          ),
        );
    }

    consoleLog(`Token Inválido - url: ${url}`, pVerbose.erro);
    return resp
      .status(403)
      .json(
        retornoPadrao(1, `Sessão Expirada! Realize a autenticação novamente`),
      );
  }
};

export {
  decryptToken, encryptToken, gerarToken, gerarTokenColaborador, getDataToRefresh
};

