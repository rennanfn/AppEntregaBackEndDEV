/* eslint-disable prettier/prettier */
import { iProdutosPodeRetirar } from '../controller/Cad_ProdRestricao_Controller';
import { CadProdRestricaoDB } from '../modelDB/Cad_ProdRestricao_DB';
import {
  iProdSemRestricao,
  iVerificaPeriodicidade,
  pBolean,
} from '../model/Cad_ProdRestricao';
import { Connection } from 'mysql2/promise';
import { CadColaboradorDB } from '../modelDB/Cad_Colaborador_DB';


/**
 * Faz uma série de validações para saber quais os produtos que o colaborador pode retirar.
 * @param matricula matricula do colaborador
 * @param connection Conexão com o BD
 * @returns Retorna uma lista de produtos que o colaborador pode retirar
 */
export async function buscaProdutosColabPodeRetirar(
  matricula: number,
  connection: Connection,
): Promise<iProdutosPodeRetirar> {
  const prodSemRestricao = new CadProdRestricaoDB();
  try {
    // ---------------------------------------------------------
    // Busca os produtos que o colaborador não tenha restrição
    // _________________________________________________________
    const prods = await prodSemRestricao.getProdutosSemRestricao(
      matricula,
      connection,
    );
    if (!prods) {
      // Se não encontrou nada, retorna vazio
      const resposta: iProdutosPodeRetirar = {
        produtos: [],
      };
      return Promise.resolve(resposta);
    }
    // ---------------------------------------------------------
    // Remove os produtos quen não devem ser entregues se o colaborador entrou a menos de 30 dias;
    // ---------------------------------------------------------
    const prodTrinta = await prodSemRestricao.ProdTrintaDias(
      prods,
      matricula,
      connection,
    );

    // ---------------------------------------------------------
    // Passa os produtos pelo filtro de comodato para marcar se o colaborador deve algum comodato.
    // ---------------------------------------------------------
    const prodComodato = await prodSemRestricao.ProdPendComodato(
      prodTrinta,
      matricula,
      connection,
    );
    // ---------------------------------------------------------
    // Passa os produtos pelo filtro de periodicidade para saber se o colaborador já retirou esse item ou se retirou parcialmente.
    // ---------------------------------------------------------
    const arrayPromise = prodComodato.map<Promise<iVerificaPeriodicidade>>(
      prod => {
        return prodSemRestricao.VerificaSeJaRetirouNaPeriodicidade(
          matricula,
          prod,
          connection,
        );
      },
    );
    const retornos = await Promise.all(arrayPromise);
    const prodsVerificadosPeriodicidade = prodComodato.reduce<
      iProdSemRestricao[]
    >((prodAcc, prodAtual) => {
      const prodVerificadoPeriodicidade = retornos.find(
        ret => ret.id_produto === prodAtual.id,
      );
      // Se não encontrou o produto no array de verificados pela periodicidade não retorna ele (o correto é ele retornar todos os itens)
      if (!prodVerificadoPeriodicidade) return prodAcc;
      // Se o produto vier com o status que NÃO pode ser retirado então não adionamos ele no retorno,
      if (!prodVerificadoPeriodicidade.pode_retirar) return prodAcc;
      // Se o produto pode ser retirado, verifica se ele já retirou alguma quantidade indicando que ele já retirou esse item parcialmente.
      const newProd = prodAtual;
      newProd.qtd_max_retirada =
        prodAtual.qtd_max_retirada -
        prodVerificadoPeriodicidade.qtd_ja_retirada;
      prodAcc.push(newProd);
      return prodAcc;
    }, []);

    // ---------------------------------------------------------
    // Filtra produtos que devem ser entregue no aniverário do colaborador.
    // ---------------------------------------------------------
    const colaboradorDB = new CadColaboradorDB();
    const mesAniversario = await colaboradorDB.MesAniversarioColaborador(
      matricula,
      connection,
    );
    const produtosFiltroAniversario = prodsVerificadosPeriodicidade.filter(
      prod => {
        // Se o produto pode ser entregue em qualquer data retorna ele;
        if (prod.entrega_somente_aniversario === pBolean.nao) return true;
        // Se o produto só pode ser entregue no aniverário e for o mês do aniversário retorna o produto;
        if (prod.entrega_somente_aniversario === pBolean.sim && mesAniversario)
          return true;
        // Se o item só pode ser entregue no aniversário e não for aniversário dele então não retorna;
        return false;
      },
    );
    const resposta: iProdutosPodeRetirar = {
      produtos: produtosFiltroAniversario,
    };
    return Promise.resolve(resposta);
  } catch (error) {
    return Promise.reject(error);
  }
}
